<?php
/**
 * 角色业务封装。
 * @author fingerQin
 * @date 2015-10-30
 */

namespace services;

use finger\Validator;
use finger\DbBase;
use common\YUrl;
use common\YCore;
use models\Project;
use models\Dynamic;
use models\Taskcoe;
use models\UserBlacklist;
use models\UserData;
use models\User;
use models\UserLogin;
use models\UserBind;
use models\FindPwd;
use services\GoldService;
use function Sodium\add;

class RoleService extends AbstractService
{
    public static function createRoleTable($projectNickname)
    {
        $tablename = "pt_".$projectNickname."_role";
        $roleModel     = new Dynamic($tablename);
        $columns = array(
            array("name"=>"role_id","type"=>"INT","constraints"=>"AUTO_INCREMENT COMMENT '主键ID'"),
            array("name"=>"role_name","type"=>"CHAR(20)","constraints"=>"UNIQUE COMMENT '角色名'"),
            array("name"=>"manage_member","type"=>"BOOL","constraints"=>"COMMENT '允许管理成员'"),
            array("name"=>"manage_role","type"=>"BOOL","constraints"=>"COMMENT '允许管理角色'"),
            array("name"=>"manage_project","type"=>"BOOL","constraints"=>"COMMENT '允许管理当前项目'"),
            array("name"=>"manage_taskcoe","type"=>"BOOL","constraints"=>"COMMENT '允许管理工时系数'"),
            array("name"=>"audit_manhour","type"=>"BOOL","constraints"=>"COMMENT '允许审核工时'"),
            array("name"=>"consult_manhour","type"=>"BOOL","constraints"=>"COMMENT '允许查看工时'"),
            array("name"=>"create_manhour","type"=>"BOOL","constraints"=>"COMMENT '允许创建工时'"),
            array("name"=>"delete_manhour","type"=>"BOOL","constraints"=>"COMMENT '允许删除工时'"),
        );
        $tailConstraints = "PRIMARY KEY (role_id)";
        $ok = $roleModel->createTable($tablename,$columns,$tailConstraints);
        return $ok;
    }

    public static function deleteRoleTable($projectNickname)
    {
        $rolemodel = new Dynamic("pt_".$projectNickname."_role");
        $rolemodel->deleteTable();
    }

    public static function getRoleList($projectNickname)
    {
        $roleModel = new Dynamic("pt_".$projectNickname."_role");
        $result = $roleModel->fetchAll([],[]);
        return $result;
    }

    public static function addRole($adderUserId,$projectNickname,$roleName,$manageProject,$manageMember,$manageRole,
                                   $manageTaskcoe,$auditManhour,$consultManhour,$createManhour,$deleteManhour,$needVerify=true)
    {
        if ($needVerify){
            $adderRoleId = MemberService::getMember($projectNickname,$adderUserId)["role_id"];
            $manageRoleAuthority = self::getRole($adderUserId,$projectNickname,$adderRoleId)["manage_role"];
            if(!$manageRoleAuthority){
                YCore::exception(STATUS_ERROR, '没有添加角色的权限');
            }
        }
        $data = ["role_name"=>$roleName,
            "manage_project"=>$manageProject,
            "manage_member"=>$manageMember,
            "manage_role"=>$manageRole,
            "manage_taskcoe"=>$manageTaskcoe,
            "audit_manhour"=>$auditManhour,
            "consult_manhour"=>$consultManhour,
            "create_manhour"=>$createManhour,
            "delete_manhour"=>$deleteManhour];
        $roleModel = new Dynamic("pt_".$projectNickname."_role");
        $id = $roleModel->insert($data);
        if($id===0){
            YCore::exception(STATUS_ERROR, '角色添加失败');
        }
        return $id;
    }

    public static function deleteRole($deleterUserId,$projectNickname,$roleId)
    {

        $deleterRoleId = MemberService::getMember($projectNickname,$deleterUserId)["role_id"];
        $manageRoleAuthority = RoleService::getRole($deleterUserId,$projectNickname,$deleterRoleId)["manage_role"];
        if(!$manageRoleAuthority){
            YCore::exception(STATUS_ERROR, '没有删除角色的权限');
        }
        $roleModel = new Dynamic("pt_".$projectNickname."_role");
        $where = ["role_id"=>$roleId];
        $ok = $roleModel->delete($where);
        if($ok==0){
            YCore::exception(STATUS_ERROR, '角色删除失败');
        }
    }
    public static function editRole($editorUserId,$projectNickname,$roleName,$manageProject,$manageMember,$manageRole,
                $manageTaskcoe,$auditManhour,$consultManhour,$createManhour,$deleteManhour,$roleId)
    {
        $editorRoleId = MemberService::getMember($projectNickname,$editorUserId)["role_id"];
        $manageRoleAuthority = self::getRole($editorUserId,$projectNickname,$editorRoleId)["manage_role"];
        if(!$manageRoleAuthority){
            YCore::exception(STATUS_ERROR, '没有编辑角色的权限');
        }
        $data = ["role_name"=>$roleName,
            "manage_project"=>$manageProject,
            "manage_member"=>$manageMember,
            "manage_role"=>$manageRole,
            "manage_taskcoe"=>$manageTaskcoe,
            "audit_manhour"=>$auditManhour,
            "consult_manhour"=>$consultManhour,
            "create_manhour"=>$createManhour,
            "delete_manhour"=>$deleteManhour];
        $where = ["role_id"=>$roleId];

        $roleModel = new Dynamic("pt_".$projectNickname."_role");
        $id = $roleModel->update($data,$where);
        if($id==0){
            YCore::exception(STATUS_ERROR, '角色编辑失败');
        }
    }
    public static function getRole($getterUserId,$projectNickname,$roleId,$needVerify=true)
    {
        if($needVerify){
            $member = MemberService::getMember($projectNickname,$getterUserId);
        }
        $roleModel = new Dynamic("pt_".$projectNickname."_role");
        $columns = [];
        $where = ["role_id"=>$roleId];
        $role = $roleModel->fetchOne($columns,$where);
        if (empty($role)) {
            YCore::exception(STATUS_ERROR, '角色不存在或已经删除');
        }
        return $role;
    }
}