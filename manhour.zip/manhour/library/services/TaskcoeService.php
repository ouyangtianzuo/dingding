<?php
/**
 * 工时业务封装。
 * @author fingerQin
 * @date 2015-10-30
 */

namespace services;

use finger\Validator;
use finger\DbBase;
use common\YUrl;
use common\YCore;
use models\AbstractBase;
use models\Dynamic;
use models\UserBlacklist;
use models\UserData;
use models\User;
use models\UserLogin;
use models\UserBind;
use models\FindPwd;
use services\MemberService;

class TaskcoeService extends AbstractService
{
    public static function getTaskcoeList($projectNickname)
    {
        $taskcoeModel = new Dynamic("pt_" . $projectNickname . "_taskcoe");
        $result = $taskcoeModel->fetchAll([],[]);
        return $result;
    }

    public static function createTaskcoeTable($projectNickname)
    {
        $tablename = "pt_" . $projectNickname . "_taskcoe";
        $taskcoeModel = new Dynamic($tablename);
        $columns = array(
            array("name" => "taskcoe_id", "type" => "INT","constraints"=>"AUTO_INCREMENT COMMENT '主键ID'"),
            array("name" => "taskcoe_name", "type" => "CHAR(50)","constraints"=>"UNIQUE COMMENT '工时系数名称'"),
            array("name" => "max_taskcoe_value", "type" => "FLOAT","constraints"=>"COMMENT '工时系数最大值'"),
            array("name" => "min_taskcoe_value", "type" => "FLOAT","constraints"=>"COMMENT '工时系数最小值'"),
            array("name" => "recommend_taskcoe_value", "type" => "FLOAT","constraints"=>"COMMENT '工时系数推荐值'"),
            array("name" => "taskcoe_describe", "type" => "CHAR(200)","constraints"=>"COMMENT '工时系数描述'")
        );
        $tail_constraints =
            "PRIMARY KEY (taskcoe_id)";
        $ok = $taskcoeModel->createTable($tablename,$columns,$tail_constraints);
        return $ok;
    }

    public static function deleteTaskcoeTable($project_nickname)
    {
        $manhourModel     = new Dynamic("pt_".$project_nickname."_taskcoe");
        $manhourModel->deleteTable();
    }

    public static function createTaskcoe($projectNickname, $createrUserId, $taskcoeName, $recommendTaskcoeValue,$minTaskcoeValue,$maxTaskcoeValue,$taskcoeDescribe)
    {
        $createrRoleId = MemberService::getMember($projectNickname,$createrUserId)["role_id"];
        $createTakscoeAuthority = RoleService::getRole($createrUserId,$projectNickname,$createrRoleId)["manage_taskcoe"];

        if(!$createTakscoeAuthority){
            YCore::exception(STATUS_ERROR, '没有创建工时系数的权限');
        }
        $taskcoeModel = new Dynamic("pt_".$projectNickname."_taskcoe");
        $data = ["taskcoe_name"=>$taskcoeName,
            "recommend_taskcoe_value"=>$recommendTaskcoeValue,
            "min_taskcoe_value"=>$minTaskcoeValue,
            "max_taskcoe_value"=>$maxTaskcoeValue,
            "taskcoe_describe"=>$taskcoeDescribe];
        $id = $taskcoeModel->insert($data);
        if ($id===0){
            YCore::exception(STATUS_ERROR, '工时系数添加失败');
        }
    }
    public static function deleteTaskcoe($projectNickname,$deleterUserId,$taskcoeId)
    {
        $deleterRoleId = MemberService::getMember($projectNickname,$deleterUserId)["role_id"];
        $manageTaskcoeAuthority = RoleService::getRole($deleterUserId,$projectNickname,$deleterRoleId)["manage_taskcoe"];
        if(!$manageTaskcoeAuthority){
            YCore::exception(STATUS_ERROR, '没有删除工时系数的权限');
        }
        $taskcoeModel = new Dynamic("pt_".$projectNickname."_taskcoe");
        $ok = $taskcoeModel->delete(["taskcoe_id"=>$taskcoeId]);
        if (!$ok){
            YCore::exception(STATUS_ERROR, '工时系数删除失败');
        }
    }
    public static function editTaskcoe($projectNickname,$editorUserId,$taskcoeId,$taskcoeName, $recommendTaskcoeValue,$minTaskcoeValue,$maxTaskcoeValue,$taskcoeDescribe)
    {
        $editorRoleId = MemberService::getMember($projectNickname,$editorUserId)["role_id"];
        $manageUserAuthority = RoleService::getRole($editorRoleId,$projectNickname,$editorRoleId)["manage_taskcoe"];
        if(!$manageUserAuthority){
            YCore::exception(STATUS_ERROR, '没有修改工时系数的权限');
        }
        $taskcoeModel = new Dynamic("pt_".$projectNickname."_taskcoe");
        $data = ["taskcoe_name"=>$taskcoeName,
            "recommend_taskcoe_value"=>$recommendTaskcoeValue,
            "min_taskcoe_value"=>$minTaskcoeValue,
            "max_taskcoe_value"=>$maxTaskcoeValue,
            "taskcoe_describe"=>$taskcoeDescribe];
        $where = ["taskcoe_id"=>$taskcoeId];
        $ok = $taskcoeModel->update($data,$where);
        if ($ok===0){
            YCore::exception(STATUS_ERROR, '工时系数修改失败');
        }
    }

    public static function getTaskcoeById($projectNickname,$taskcoeId)
    {
        $taskcoeModel = new Dynamic("pt_".$projectNickname."_taskcoe");
        $columns = [];
        $where = ["taskcoe_id" => $taskcoeId];
        $taskcoeInfo = $taskcoeModel->FetchOne($columns,$where);
        if (empty($taskcoeInfo)) {
            YCore::exception(STATUS_ERROR, '工时系数信息不存在');
        }
        return $taskcoeInfo;
    }
}