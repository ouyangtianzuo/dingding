<?php
/**
 * 角色业务封装。
 * @author fingerQin
 * @date 2015-10-30
 */

namespace services;

use finger\Validator;
use finger\DbBase;
use common\YUrl;
use common\YCore;
use models\Project;
use models\Dynamic;
use models\Taskcoe;
use models\UserBlacklist;
use models\UserData;
use models\User;
use models\UserLogin;
use models\UserBind;
use models\FindPwd;
use services\GoldService;
use function Sodium\add;

class MemberService extends AbstractService
{

    public static function createMemberTable($projectNickname)
    {
        $tablename = "pt_" . $projectNickname . "_member";
        $memberModel = new Dynamic($tablename);
        $columns = array(
            array("name" => "id", "type" => "INT", "constraints" => "AUTO_INCREMENT COMMENT '主键ID'"),
            array("name" => "user_id", "type" => "INT", "constraints" => "UNIQUE COMMENT '用户ID'"),
            array("name" => "role_id", "type" => "INT", "constraints" => "COMMENT '角色ID'")
        );
        $tail_constraints =
            "FOREIGN KEY (user_id) REFERENCES user(user_id)," .
            "PRIMARY KEY (id)," .
            "FOREIGN KEY (role_id) REFERENCES pt_" . $projectNickname . "_role(role_id)";
        $ok = $memberModel->createTable($tablename, $columns, $tail_constraints);
        return $ok;
    }

    public static function deleteMemberTable($projectNickname)
    {
        $memberModel = new Dynamic("pt_" . $projectNickname . "_member");
        $memberModel->deleteTable();
    }

    public static function addMember($adderUserId, $userId, $projectNickname, $roleId, $needVerify = true)
    {
        if ($needVerify) {
            $adderRoleId = MemberService::getMember($projectNickname, $adderUserId)["role_id"];
            $manageMemberAuthority = RoleService::getRole($adderUserId,$projectNickname, $adderRoleId)["manage_member"];
            if (!$manageMemberAuthority) {
                YCore::exception(STATUS_ERROR, '没有添加成员的权限');
            }
        }

        $memberModel = new Dynamic("pt_" . $projectNickname . "_member");
        $data = ["user_id" => $userId,
            "role_id" => $roleId];
        $id = $memberModel->insert($data);
        if ($id === 0) {
            YCore::exception(STATUS_ERROR, '成员添加失败');
        }
    }

    public static function removeMember($deleterUserId, $userId, $projectNickname)
    {
        $deleterRoleId = self::getMember($projectNickname, $deleterUserId)["role_id"];
        $manageMemberAuthority = RoleService::getRole($deleterUserId,$projectNickname, $deleterRoleId)["manage_member"];
        if (!$manageMemberAuthority) {
            YCore::exception(STATUS_ERROR, '没有删除成员的权限');
        }
        $memberModel = new Dynamic("pt_" . $projectNickname . "_member");
        $ok = $memberModel->delete(["user_id" => $userId]);
        if (!$ok) {
            YCore::exception(STATUS_ERROR, '成员删除失败');
        }
    }

    public static function editMember($editorUserId, $userId, $projectNickname, $roleId)
    {
        $editorRoleId = self::getMember($projectNickname, $editorUserId)["role_id"];
        $manageMemberAuthority = RoleService::getRole($editorUserId,$projectNickname, $editorRoleId)["manage_member"];
        if (!$manageMemberAuthority) {
            YCore::exception(STATUS_ERROR, '没有修改成员的权限');
        }
        $memberModel = new Dynamic("pt_" . $projectNickname."_member");
        $data = ["role_id" => $roleId];
        $where = ["user_id" => $userId];
        $id = $memberModel->update($data, $where);
        if ($id === 0) {
            YCore::exception(STATUS_ERROR, '成员修改失败');
        }
    }

    public static function getMember($projectNickname, $userId)
    {
        $memberModel = new Dynamic("pt_" . $projectNickname . "_member");
        $columns = [];
        $where = ["user_id" => $userId];

        $memberInfo = $memberModel->FetchOne($columns, $where);
        if (empty($memberInfo)) {
            YCore::exception(STATUS_ERROR, '用户不在项目内');
        }
        return $memberInfo;
    }

    public static function getMemberList($userId,$projectNickname)
    {
        $memberModel = new Dynamic("pt_" . $projectNickname . "_member");
        $memberList = $memberModel->fetchAll([],[]);
        foreach ($memberList as $key=>&$member){
            $member['realname'] =  UserService::getUserDetail($member['user_id'])['realname'];
            $member['roleName'] =  RoleService::getRole($userId,$projectNickname,$member['role_id'])["role_name"];
        }
        return $memberList;
    }

    public static function getMemberindex($projectNickname)
    {
        $memberModel = new Dynamic("pt_" . $projectNickname . "_member");
        $memberinfo = $memberModel->fetchAll([],[]);
        $arraylength = count($memberinfo);
        for ($x=0; $x<$arraylength;$x++)
        {
            $result[$x]['userinfo'] = UserService::getUserDetail($memberinfo[$x]['user_id']);
            $roleId = $memberinfo[$x]['role_id'];
            $roleModel = new Dynamic("pt_".$projectNickname."_role");
            $columns = [];
            $where = ["role_id"=>$roleId];
            $role = $roleModel->fetchOne($columns,$where);
            $result[$x]['role_name'] = $role['role_name'];

        }
        return $result;
    }



    public static function getnotinProject($projectNickname, $userList)
    {
        $arraylength = count($userList);
        $y=0;
        for ($x=0; $x<$arraylength;$x++)
        {
            $userId = $userList[$x]['user_id'];
            $columns = [];
            $where = ["user_id" => $userId];
            $memberModel = new Dynamic("pt_" . $projectNickname . "_member");
            $memberInfo = $memberModel->FetchOne($columns, $where);
            if (empty($memberInfo)) {
                $memberList[$y]['membername'] = UserService::getUserDetail($userId)['username'];
                $memberList[$y]['user_id'] = $userId;
                $y++;
            }
        }

        return $memberList;
    }

    public static function getauditList($userId,$projectNickname)
    {
        $memberList = self::getMemberList($userId,$projectNickname);
        $auditList = [];
        foreach ($memberList as $member){
            $roleId = $member['role_id'];
            $role = RoleService::getRole($userId,$projectNickname,$roleId,false);
            if ($role['audit_manhour']){
                $auditList[] = UserService::getUserDetail($member['user_id']);
            }
        }
        return $auditList;
    }
}