<?php
/**
 * 工时业务封装。
 * @author fingerQin
 * @date 2015-10-30
 */

namespace services;

use finger\Validator;
use finger\DbBase;
use common\YUrl;
use common\YCore;
use models\AbstractBase;
use models\Dynamic;
use models\UserBlacklist;
use models\UserData;
use models\User;
use models\UserLogin;
use models\UserBind;
use models\FindPwd;
use services\MemberService;

class ManhourService extends AbstractService
{
    public static function getManhourList($projectNickname)
    {
        $manhourModel = new Dynamic("pt_" . $projectNickname . "_manhour");
        $result = $manhourModel->fetchAll([],[]);
        return $result;
    }

    public static function createManhourTable($projectNickname)
    {
        $tablename = "pt_" . $projectNickname . "_manhour";
        $manhourModel = new Dynamic($tablename);
        $columns = array(
            array("name" => "manhour_id", "type" => "INT","constraints"=>"AUTO_INCREMENT COMMENT '主键ID'"),
            array("name" => "user_id", "type" => "INT","constraints"=>"COMMENT '用户ID'"),
            array("name" => "taskcoe_id", "type" => "INT","constraints"=>"COMMENT '工作类型ID'"),
            array("name" => "taskcoe_value", "type" => "FLOAT","constraints"=>"COMMENT '工时系数数值'"),
            array("name" => "work_content", "type" => "CHAR(50)","constraints"=>"COMMENT '工作内容'"),
            array("name" => "manhour", "type" => "FLOAT","constraints"=>"COMMENT '占用工时'"),
            array("name" => "over_time_manhour", "type" => "FLOAT","constraints"=>"COMMENT '加班工时'"),
            array("name" => "workdate", "type" => "DATE","constraints"=>"COMMENT '工作日期'"),
            array("name" => "audit_user_id", "type" => "INT","constraints"=>"COMMENT '审核人ID'"),
            array("name" => "effciency_coe", "type" => "FLOAT","constraints"=>"COMMENT '效率系数'"),
            array("name" => "is_fact", "type" => "BOOLEAN","constraints"=>"COMMENT '是否属实'"),
            array("name" => "quality_coe", "type" => "FLOAT","constraints"=>"COMMENT '完成度'"),
            array("name" => "is_audit", "type" => "ENUM('0','1','2')","constraints"=>" DEFAULT '0' COMMENT '是否审核'"),
        );
        $tail_constraints =
            "FOREIGN KEY (user_id) REFERENCES user(user_id), ".
            "FOREIGN KEY (taskcoe_id) REFERENCES "."pt_" . $projectNickname . "_taskcoe "."(taskcoe_id), ".
            "PRIMARY KEY (manhour_id)";
        $ok = $manhourModel->createTable($tablename,$columns,$tail_constraints);
        return $ok;
    }

    public static function deleteManhourTable($project_nickname)
    {
        $manhourModel     = new Dynamic("pt_".$project_nickname."_manhour");
        $manhourModel->deleteTable();
    }

    public static function createManhour($projectNickname,$createrUserId,$taskcoeId,$workContent,$manhour,$overtimeManhour,$workdate,$auditUserId)
    {
        $createrRoleId = MemberService::getMember($projectNickname,$createrUserId)["role_id"];
        $createManhourAuthority = RoleService::getRole($createrUserId,$projectNickname,$createrRoleId)["create_manhour"];
        if(!$createManhourAuthority){
            YCore::exception(STATUS_ERROR, '没有创建工时的权限');
        }
        $manhourModel = new Dynamic("pt_".$projectNickname."_manhour");

        $data = ["user_id"=>$createrUserId,
            "taskcoe_id"=>$taskcoeId,
            "work_content"=>$workContent,
            "manhour"=>$manhour,
            "over_time_manhour"=>$overtimeManhour,
            "audit_user_id"=>$auditUserId,
            "workdate"=>$workdate];
        $id = $manhourModel->insert($data);
        if ($id===0){
            YCore::exception(STATUS_ERROR, '工时添加失败');
        }
    }
    public static function deleteManhour($projectNickname,$deleterUserId,$manhourId)
    {
        $deleterRoleId = MemberService::getMember($projectNickname,$deleterUserId)["role_id"];
        $manageManhourAuthority = RoleService::getRole($deleterUserId,$projectNickname,$deleterRoleId)["delete_manhour"];
        if(!$manageManhourAuthority){
            YCore::exception(STATUS_ERROR, '没有删除工时的权限');
        }
        $manhourModel = new Dynamic("pt_".$projectNickname."_manhour");
        $ok = $manhourModel->fakeDelete(["manhour_id"=>$manhourId]);
        if (!$ok){
            YCore::exception(STATUS_ERROR, '工时删除失败');
        }
    }
    public static function editManhour($projectNickname,$editorUserId,$taskcoeId,$workContent,$manhour,$overtimeManhour,$workdate,$auditUserId,$manhourId)
    {
//        $editorRoleId = MemberService::getMember($projectNickname,$editorUserId)["role_id"];
//        $manageUserAuthority = RoleService::getRole($editorRoleId,$projectNickname,$editorRoleId)["manage_member"];
//        if(!$manageUserAuthority){
//            YCore::exception(STATUS_ERROR, '没有修改用户的权限');
//        }
        $manhourModel = new Dynamic("pt_".$projectNickname."_manhour");
        $manhourInfo = self::getManhour($projectNickname,$manhourId);
        if ($manhourInfo["is_audit"]==1){
            YCore::exception(STATUS_ERROR, '该工时已经被审核，无法修改');
        }
        if ($manhourInfo["user_id"]!=$editorUserId and $manhourInfo["audit_user_id"]!=$editorUserId){
            YCore::exception(STATUS_ERROR, '没有权限修改工时');
        }
        $data = ["work_content"=>$workContent,
            "taskcoe_id"=>$taskcoeId,
            "manhour"=>$manhour,
            "over_time_manhour"=>$overtimeManhour,
            "workdate"=>$workdate,
            "audit_user_id"=>$auditUserId,
            "is_audit"=>0];
        $where = ["manhour_id"=>$manhourId];
        $ok = $manhourModel->update($data,$where);
        if ($ok===0){
            YCore::exception(STATUS_ERROR, '工时修改失败');
        }
    }

    public static function removeManhour($projectNickname,$deletUserId,$manhourId)
    {
        $manhourModel = new Dynamic("pt_".$projectNickname."_manhour");
        $manhourInfo = self::getManhour($projectNickname,$manhourId);
        if ($manhourInfo["is_audit"]==1){
            YCore::exception(STATUS_ERROR, '该工时已经被审核，无法删除');
        }
        if ($manhourInfo["user_id"]!=$deletUserId and $manhourInfo["audit_user_id"]!=$deletUserId){
            YCore::exception(STATUS_ERROR, '没有权限删除工时');
        }
        $ok = $manhourModel->delete(["manhour_id"=>$manhourId]);
        if (!$ok){
            YCore::exception(STATUS_ERROR, '工时删除失败');
        }
    }

    public static function getManhour($projectNickname,$manhourId)
    {
        $manhourModel = new Dynamic("pt_".$projectNickname."_manhour");
        $columns = [];
        $where = ["manhour_id" => $manhourId];
        $manhourInfo = $manhourModel->FetchOne($columns,$where);
        if (empty($manhourInfo)) {
            YCore::exception(STATUS_ERROR, '工时信息不存在');
        }
        return $manhourInfo;
    }

    public static function auditManhour($projectNickname,$auditorUserId,$manhourId,$taskcoeValue,$effciencyCoe,$isFact,$qualityCoe)
    {
        $auditorRoleId = MemberService::getMember($projectNickname,$auditorUserId)["role_id"];
        $auditManhourAuthority = RoleService::getRole($auditorUserId,$projectNickname,$auditorRoleId)["audit_manhour"];
        if(!$auditManhourAuthority){
            YCore::exception(STATUS_ERROR, '没有审核工时的权限');
        }
        $manhourModel = new Dynamic("pt_".$projectNickname."_manhour");
        $manhourInfo = self::getManhour($projectNickname,$manhourId);
        if ($manhourInfo["is_audit"]){
            YCore::exception(STATUS_ERROR, '该工时已经被审核 无法再次审核');
        }

        if ($manhourInfo["audit_user_id"]!=$auditorUserId){
            YCore::exception(STATUS_ERROR, '没有审核此工时的权限');
        }
        $data = ["effciency_coe"=>$effciencyCoe,
            "taskcoe_value"=>$taskcoeValue,
            "is_fact"=>$isFact,
            "quality_coe"=>$qualityCoe,
            "is_audit"=>1];
        $where = ["manhour_id"=>$manhourId];
        $ok = $manhourModel->update($data,$where);
        if ($ok===0){
            YCore::exception(STATUS_ERROR, '工时审核失败');
        }
    }

    public static function rejectManhour($projectNickname,$auditorUserId,$manhourId)
    {
        $auditorRoleId = MemberService::getMember($projectNickname,$auditorUserId)["role_id"];
        $auditManhourAuthority = RoleService::getRole($auditorUserId,$projectNickname,$auditorRoleId)["audit_manhour"];
        if(!$auditManhourAuthority){
            YCore::exception(STATUS_ERROR, '没有审核工时的权限');
        }
        $manhourModel = new Dynamic("pt_".$projectNickname."_manhour");
        $manhourInfo = self::getManhour($projectNickname,$manhourId);
        if ($manhourInfo["is_audit"]){
            YCore::exception(STATUS_ERROR, '该工时已经被审核 无法再次审核');
        }
        if ($manhourInfo["audit_user_id"]!=$auditorUserId){
            YCore::exception(STATUS_ERROR, '没有审核此工时的权限');
        }
        $data = [
            "is_audit"=>2];
        $where = ["manhour_id"=>$manhourId];
        $ok = $manhourModel->update($data,$where);
        if ($ok===0){
            YCore::exception(STATUS_ERROR, '工时退回失败');
        }
    }


}