<?php
/**
 * 项目业务封装。
 * @author fingerQin
 * @date 2015-10-30
 */

namespace services;

use finger\Validator;
use finger\DbBase;
use common\YUrl;
use common\YCore;
use models\AbstractBase;
use models\Project;
use models\Taskcoe;
use models\UserBlacklist;
use models\UserData;
use models\User;
use models\Dynamic;
use models\UserLogin;
use models\UserBind;
use models\FindPwd;

class ProjectService extends AbstractService
{
    public static function checkProjectNickname($projectNickname)
    {
        $data  = ['$project_nickname' => $projectNickname];
        $rules = [
            '$project_nickname' => '项目标识|require|alpha_dash|len:2:20:0'
        ];
        Validator::valido($data, $rules);
    }

    public static function getNickname($projectId)
    {
        $projectModel = new Project();
        $where = ["project_id"=>$projectId];
        $columns = [];
        $projectData = $projectModel->fetchOne($columns,$where);
        if(empty($projectData)){
            YCore::exception(STATUS_ERROR, '项目不存在');
        }
        return $projectData["project_nickname"];
    }
    public static function getName($projectId)
    {
        $projectModel = new Project();
        $where = ["project_id"=>$projectId];
        $columns = [];
        $projectData = $projectModel->fetchOne($columns,$where);
        if(empty($projectData)){
            YCore::exception(STATUS_ERROR, '项目不存在');
        }
        return $projectData["project_name"];
    }

    public static function getProjectList($where)
    {
        $projectModel = new Project();
        $result = $projectModel->fetchAll([],$where);
        return $result;
    }

    public static function createProject($adderUserId,$projectName,$projectStatus,$projectType,$projectNickname)
    {
        //在project_info表中添加项目名
        self::registerProject($adderUserId,$projectName,$projectStatus,$projectType,$projectNickname);
        RoleService::createRoleTable($projectNickname);
        MemberService::createMemberTable($projectNickname);
        TaskcoeService::createTaskcoeTable($projectNickname);
        ManhourService::createManhourTable($projectNickname);
        $roleId = RoleService::addRole($adderUserId,$projectNickname,"管理员",true,true,true,true,true,true,true,true,false);
        MemberService::addMember($adderUserId,$adderUserId,$projectNickname,$roleId,false);
        return true;
    }

    public static function registerProject($userId,$projectName,$projectStatus,$projectType,$projectNickname)
    {
        $userDataModel = new UserData();
        $columns = [];
        $where = ["user_id"=>$userId];
        $createProjectAuthority = $userDataModel->fetchOne($columns,$where)["create_project"];
        if (!$createProjectAuthority){
            YCore::exception(STATUS_ERROR, '没有权限创建项目');
        }

        $dbBase = new DbBase();
        $dbBase->beginTransaction();
        $ProjectModel  = new Project();
        $insertData = [
            'project_name'         => $projectName,
            'project_status'         => $projectStatus,
            'project_type'         => $projectType,
            'project_nickname'             => $projectNickname,
        ];
        $projectId = $ProjectModel->insert($insertData);
        if ($projectId == 0) {
            $dbBase->rollBack();
            YCore::exception(STATUS_SERVER_ERROR, '服务器繁忙,请稍候重试');
        }
        $dbBase->commit();
        return $projectId;
    }

    public static function deleteProject($userId,$projectId)
    {
        $projectNickname = self::getNickname($projectId);
        $roleId = MemberService::getMember($projectNickname,$userId)["role_id"];
        $deleteProjectAuthority = RoleService::getRole($userId,$projectNickname,$roleId)["manage_project"];

        if (!$deleteProjectAuthority){
            YCore::exception(STATUS_ERROR, '没有权限删除项目');
        }
        //在project_info删除项目名

        ManhourService::deleteManhourTable($projectNickname);
        TaskcoeService::deleteTaskcoeTable($projectNickname);
        MemberService::deleteMemberTable($projectNickname);
        RoleService::deleteRoleTable($projectNickname);
        $projectModel = new Project();
        $projectModel->delete(["project_id"=>$projectId]);
        return true;
    }

    public static function getProjectTaskCoe($project_id)
    {
        $taskcoeModel = new Taskcoe();
        $columns = [];
        $where = ["project_id" => $project_id];
        $taskcoeinfo = $taskcoeModel->FetchOne($columns,$where);
        if (empty($taskcoeinfo)) {
            YCore::exception(STATUS_ERROR, '项目工作系数信息不存在');
        }
        return $taskcoeinfo;
    }

    public static function getProject($projectId)
    {
        $projectModel = new Project();
        $columns = [];
        $where = ["project_id"=>$projectId];
        $projectData = $projectModel->fetchOne($columns,$where);
        if (empty($projectData)) {
            YCore::exception(STATUS_ERROR, '项目不存在或已经删除');
        }
        return $projectData;
    }
    public static function editProject($userId,$projectId,$projectName,$projectType,$projectStatus)
    {
        $projectNickname = self::getNickname($projectId);
        $roleId =  MemberService::getMember($projectNickname,$userId)["role_id"];
        $manageProjectAuthority = RoleService::getRole($userId,$projectNickname,$roleId)["manage_project"];
        if(!$manageProjectAuthority){
            YCore::exception(STATUS_ERROR, '没有权限编辑项目');
        }

        $projectModel = new Project();
        $data   = [
            "project_name"          => $projectName,
            "project_status"      => $projectStatus,
            'project_type'         => $projectType,
        ];
        $ok = $projectModel->update($data, ['project_id' => $projectId ]);
        if (!$ok) {
            YCore::exception(STATUS_ERROR, '项目信息修改失败');}
        return true;
    }

    public static function getTaskcoe($projectId)
    {
        $taskcoeModel = new Taskcoe();
        $columns = [];
        $where = ["project_id"=>$projectId];
        $taskcoe = $taskcoeModel->FetchOne($columns,$where);
        if (empty($taskcoe)) {
            YCore::exception(STATUS_ERROR, '项目工作系数不存在或已经删除');
        }
        return $taskcoe;
    }

    public static function editTaskcoe($userId,$projectId, $reportWrite, $meetingAttend,$meetingReport,
                                       $communicate,$checkProduce)
    {
        $projectNickname = self::getNickname($projectId);
        $roleId = MemberService::getMember($projectNickname,$userId)["role_id"];
        $manageTaskcoeAuthority = RoleService::getRole($userId,$projectNickname,$roleId)["manage_taskcoe"];
        if(!$manageTaskcoeAuthority){
            YCore::exception(STATUS_ERROR, '没有权限编辑工作系数');
        }

        $taskcoeModel = new Taskcoe();
        $data   = [
            'report_write'          => $reportWrite,
            'meeting_attend'      => $meetingAttend,
            'meeting_report'      => $meetingReport,
            'communicate'      => $communicate,
            'check_produce'      => $checkProduce
        ];
        $ok = $taskcoeModel->update($data, ['project_id' => $projectId ]);
        if (!$ok) {
            YCore::exception(STATUS_ERROR, '工作系数修改失败');
        }
        return true;
    }
}