<?php

namespace finger\Alisdk\Oss\Http;

class RequestCoreException extends \Exception
{

}