<?php
/**
 * 贵宾用户公共controller。
 * --1、Yaf框架会根据特有的类名后缀(DbBase、Controller、Plugin)进行自动加载。为避免这种情况请不要以这样的名称结尾。
 * @author fingerQin
 * @date 2015-11-13
 */

namespace common\controllers;

class Guest extends Common
{
    public function init()
    {
        parent::init();
        $this->assign('moduleName', $this->_moduleName);
        $this->assign('ctrlName', $this->_ctrlName);
        $this->assign('actionName', $this->_actionName);
    }
}