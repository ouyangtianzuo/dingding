<?php
/**
 * 用户绑定表。
 * @author fingerQin
 * @date 2016-03-10
 */

namespace models;

class UserBind extends AbstractBase
{
    /**
     * 表名。
     *
     * @var string
     */
    protected $tableName = 'ms_user_bind';
}
