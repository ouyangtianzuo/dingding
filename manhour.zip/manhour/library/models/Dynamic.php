<?php
/**
 * 用户表模型。
 * @author fingerQin
 * @date 2015-11-05
 */

namespace models;

class Dynamic extends AbstractBase
{
    public function __construct($tableName)
    {
        parent::__construct();
        $this->tableName = $tableName;
    }
}
