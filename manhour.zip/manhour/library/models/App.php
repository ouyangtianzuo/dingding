<?php
/**
 * 应用 表。
 * @author fingerQin
 * @date 2017-04-09
 */

namespace models;

class App extends AbstractBase
{
    /**
     * 表名。
     *
     * @var string
     */
    protected $tableName = 'api_app';
}