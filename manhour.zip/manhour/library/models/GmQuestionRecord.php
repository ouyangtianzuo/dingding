<?php
/**
 * 题库参与记录表。
 * @author fingerQin
 * @date 2018-01-08
 */

namespace models;

class GmQuestionRecord extends AbstractBase
{
    /**
     * 表名。
     *
     * @var string
     */
    protected $tableName = 'gm_question_record';
}
