<?php
/**
 * 题库表。
 * @author fingerQin
 * @date 2018-01-08
 */

namespace models;

class GmQuestion extends AbstractBase
{
    /**
     * 表名。
     *
     * @var string
     */
    protected $tableName = 'gm_question';
}
