<?php
/**
 * 用户表模型。
 * @author fingerQin
 * @date 2015-11-05
 */

namespace models;

class User extends AbstractBase
{
    /**
     * 表名。
     *
     * @var string
     */
    protected $tableName = 'user';
}
