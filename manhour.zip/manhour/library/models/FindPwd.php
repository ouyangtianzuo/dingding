<?php
/**
 * 找回密码记录表。
 * @author fingerQin
 * @date 2016-07-02
 */

namespace models;

class FindPwd extends AbstractBase
{
    /**
     * 表名。
     *
     * @var string
     */
    protected $tableName = 'ms_find_pwd';
}
