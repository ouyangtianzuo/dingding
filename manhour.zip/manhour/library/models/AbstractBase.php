<?php
/**
 * Model 基类。
 * 
 * -- 本来想取类名为 AbstractModel,但是，名称中带 Model, Yaf 框架会自动去掉。
 * 
 * @author fingerQin
 * @date 2018-05-18
 */

namespace models;

abstract class AbstractBase extends \finger\DbBase
{
    const STATUS_INVALID = 0;   // 记录状态：无效。
    const STATUS_NORMAL  = 1;   // 记录状态：正常。
    const STATUS_DELETED = 2;   // 记录状态：已删除。

    const STATUS_YES     = 1;   // 是。
    const STATUS_NO      = 0;   // 否。

    const NONE           = -1;  // 所有地方传-1都代表此值未传。

    /**
     * 表更新时间。
     * 
     * @var string
     */
    protected $createTime = 'created_time';

    /**
     * 更新时间字段。
     * 
     * @var string
     */
    protected $updateTime = 'modified_time';

    /**
     * 执行假装删除记录操作。
     *
     * @param  array  $where 删除数据条件,不充许为空。
     * @return bool
     */
    public function fakeDelete(array $where)
    {
        $data = ['valid'=>0];
        $this->update($data, $where);
    }

    public function createTable($tableName,$columns,$tail_constraints="")
    {
        if (!is_string($tableName) || strlen($tableName) === 0) {
            YCore::exception(-1, 'The tableName parameters is wrong');
        }
        $columns[] = array("name" => "valid", "type" => "BOOLEAN", "constraints" => "NOT NULL DEFAULT TRUE COMMENT '数据有效性'");
        $columns[] = array("name" => "created_time", "type" => "DATETIME","constraints"=>"COMMENT '创建时间'");
        $columns[] = array("name" => "modified_time", "type" => "DATETIME","constraints"=>"COMMENT '修改时间'");
        $sql = "CREATE TABLE {$tableName}"."(";
        foreach ($columns as $key=>$column)
        {
            $sql.= "{$column['name']} {$column['type']}";
            if (array_key_exists("constraints",$column)){
                $sql.=" {$column['constraints']}";
            }
            if ($key!==count($columns)-1){
                $sql.=",";
            }else{
                if ($tail_constraints!==""){
                    $sql.=",".$tail_constraints;
                }
            }
        }
        $sql.=")";
        $this->writeSqlLog($sql, []);
        $sth = $this->dbClient->prepare($sql);
        $params = [];
        $ok = $sth->execute($params);
        return $ok;
    }

    public function deleteTable()
    {
        if (!is_string($this->tableName) || strlen($this->tableName) === 0) {
            YCore::exception(-1, 'The tableName parameters is wrong');
        }
        $sql = "DROP TABLE ".$this->tableName;
        $this->writeSqlLog($sql, []);
        $sth = $this->dbClient->prepare($sql);
        $params = [];
        $ok = $sth->execute($params);
        return $ok;
    }

    public function fakeDeleteTable()
    {
        $where = ["valid"=>1];
        $this->fakeDelete($where);
        $this->writeSqlLog("FAKE DELETE $this->tableName", []);
        return true;
    }
    public function fetchOne(array $columns, array $where, $orderBy = '', $groupBy = '')
    {
        $where["valid"] = 1;
        return parent::fetchOne($columns, $where, $orderBy, $groupBy);
    }

    public function fetchAll(array $columns = [], array $where = [], $limit = 0, $orderBy = '', $groupBy = '')
    {
        $where["valid"] = 1;
        return parent::fetchAll($columns, $where, $limit, $orderBy, $groupBy);
    }
}