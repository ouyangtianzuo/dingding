<?php
/**
 * 文章副表。
 * @author fingerQin
 * @date 2016-03-27
 */

namespace models;

class NewsData extends AbstractBase
{
    /**
     * 表名。
     *
     * @var string
     */
    protected $tableName = 'ms_news_data';
}
