<?php
/**
 * 管理员登录历史表。
 * @author fingerQin
 * @date 2016-04-13
 */

namespace models;

class AdminLoginHistory extends AbstractBase
{
    /**
     * 表名。
     *
     * @var string
     */
    protected $tableName = 'ms_admin_login_history';

}