<?php
/**
 * 项目管理。
 * @author fingerQin
 * @date 2018-01-11
 */

use services\ProjectService;
use services\TaskcoeService;
use common\YUrl;
use finger\Paginator;

class TaskcoeController extends \common\controllers\User
{
    /**
     * 项目信息总览。
     */
    public function indexAction()
    {
        if ($this->getGP("projectId")==null){
            $projectList = ProjectService::getProjectList($where = []);
            $this->assign("projectList",$projectList);
        }
        else {
            $projectId = $this->getInt('projectId', '');
            $projectNickname = ProjectService::getNickname($projectId);
            $taskcoeList = TaskcoeService::getTaskcoeList($projectNickname);
            $this->assign("taskcoeList",$taskcoeList);
            $this->assign("projectId",$projectId);
        }
    }
    /**
     * 项目创建（默认创建人为项目创建者）。
     */
    public function createAction()
    {
        if ($this->_request->isPost()) {
            $projectId = $this->getInt('projectId', '');
            $taskcoeName = $this->getString('taskcoeName', '');
            $recommendTaskcoeValue = $this->getFloat('recommendTaskcoeValue', '');
            $minTaskcoeValue = $this->getFloat('minTaskcoeValue', '');
            $maxTaskcoeValue = $this->getFloat('maxTaskcoeValue', '');
            $taskcoeDescribe = $this->getString('taskcoeDescribe', '');
            $projectNickname = ProjectService::getNickname($projectId);
//            var_dump($projectNickname);
            TaskcoeService::createTaskcoe($projectNickname,$this->user_id,$taskcoeName,$recommendTaskcoeValue,$minTaskcoeValue,$maxTaskcoeValue,$taskcoeDescribe);
            $url = YUrl::createFrontendUrl('Index', 'close');
            $this->success('工时系数添加成功', $url, 2);
        }
        $projectList        = ProjectService::getProjectList($where = []);
        $this->assign("projectList",$projectList);
    }
    /**
     * 项目信息编辑首页（含工作内容系数编辑）。
     */
    public function getAction()
    {
        if ($this->_request->isPost()) {
            $projectId = $this->getInt('projectId', '');
            $projectNickname =ProjectService::getNickname($projectId);
            $taskcoeList = TaskcoeService::getTaskcoe($projectNickname);
            $this->assign("taskcoeList",$taskcoeList);
        }
    }

    /**
     * 项目信息删除首页。
     */
    public function deleteAction()
    {
        if ($this->_request->isPost()) {
            $projectId = $this->getInt('projectId', '');
            $projectNickname =ProjectService::getNickname($projectId);
            $taskcoeId = $this->getInt('taskcoeId', '');
            TaskcoeService::deleteTaskcoe($projectNickname,$this->user_id,$taskcoeId);
            $url = YUrl::createFrontendUrl('Index', 'close');
            $this->success('工时系数删除成功', $url, 2);
        }
        $projectList = ProjectService::getProjectList($where = []);
        $this->assign("projectList",$projectList);
    }

    /**
     * 项目工时系数编辑首页。
     */
    public function viewAction()
    {
        if ($this->_request->isPost()) {
            $projectId = $this->getInt('projectId', '');
            $projectName = ProjectService::getName($projectId);
            $taskcoe = ProjectService::getProjectTaskCoe($projectId);
            $this->assign("projectId",$projectId);
            $this->assign("projectName",$projectName);
            $this->assign("taskcoe",$taskcoe);
        }
        $projectList = ProjectService::getProjectList($where = []);
        $this->assign("projectList",$projectList);
    }

    /**
     * 项目工时系数编辑首页。
     */
    public function editAction()
    {
        if ($this->_request->isPost()) {
            $projectId = $this->getInt('projectId', '');
            $taskcoeId = $this->getInt('taskcoeId', '');
            $taskcoeName = $this->getString('taskcoeName', '');
            $recommendTaskcoeValue = $this->getFloat('recommendTaskcoeValue', '');
            $minTaskcoeValue = $this->getFloat('minTaskcoeValue', '');
            $maxTaskcoeValue = $this->getFloat('maxTaskcoeValue', '');
            $taskcoeDescribe = $this->getString('taskcoeDescribe', '');
            $projectNickname = ProjectService::getNickname($projectId);
            TaskcoeService::editTaskcoe($projectNickname,$this->user_id,$taskcoeId,$taskcoeName,$recommendTaskcoeValue,$minTaskcoeValue,$maxTaskcoeValue,$taskcoeDescribe);
            $url = YUrl::createFrontendUrl('Index', 'close');
            $this->success('项目工时系数编辑成功', $url, 2);
        }
        $projectList = ProjectService::getProjectList($where = []);
        $this->assign("projectList",$projectList);

    }
    public function gettaskcoeAction()
    {
        if ($this->_request->isPost()) {
            $projectId = $this->getInt('projectId', '');
            $projectNickname = ProjectService::getNickname($projectId);
            $taskcoeId = $this->getInt('taskcoeId', '');
            $taskcoeInfo = TaskcoeService::getTaskcoeById($projectNickname, $taskcoeId);
        }
        $this->assign("taskcoeInfo",$taskcoeInfo);
    }
}