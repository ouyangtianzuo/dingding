<?php
/**
 * 账号管理。
 * @author fingerQin
 * @date 2018-01-11
 */

use common\YUrl;
use services\UserService;
use finger\Paginator;
use common\YCore;

class UserController extends \common\controllers\User
{
    /**
    * 用户列表。
    */
    public function indexAction()
    {
        $result = UserService::getUserDataList($where = []);
        $userDataList = $result[0];
        $userList = $result[1];
        $this->assign("userDataList",$userDataList);
        $this->assign("userList",$userList);
    }

    public function getuserListAction()
    {
        $result        = UserService::getUserList();
        $arraylength = count($result);
        $page = $this->getInt('page', '');
        $limit = $this->getInt('limit', '');

        $arraylimit = $arraylength - ($page-1) * $limit;

        for ($x=0; $x<($limit<$arraylimit?$limit:$arraylimit);$x++)
        {
            $data[$x]['user_id'] = $result[($page-1) * $limit + $x]['user_id'];
            $data[$x]['username'] = $result[($page-1) * $limit + $x]['username'];
        }

        $userList['code'] = 0;
        $userList['msg'] = '';
        $userList['count'] = $arraylength;
        $userList['data'] = $data;
        $this->assign('userList', $userList);
    }

    /**
     * 查看用户详情。
     */
    public function viewAction() {
//        $userid   = $this->getInt('user_id');
//        echo $this->user_id;
        $userinfo = UserService::getUserDetail($this->user_id);
        $this->assign('userinfo', $userinfo);
    }
    /**
     * 密码修改。
     */
    public function editPwdAction()
    {
        if ($this->_request->isPost()) {
            $oldPwd = $this->getString('oldPwd', '');
            $newPwd = $this->getString('newPwd', '');
            UserService::editPwd($this->user_id, $oldPwd, $newPwd);
            $url = YUrl::createFrontendUrl('Index', 'close');
            $this->success('修改成功', $url, 2);
        }
    }
    /**
     * 信息修改。
     */
    public function editOtherInfoAction()
    {
        if ($this->_request->isPost()) {
            $userId = $this->getString('userId', '');
            $department = $this->getInt('department', '0');
            $workgroup = $this->getInt('workgroup', '0');
            $realname = $this->getString('realname', '');
            $avatar = $this->getString('avatar', '');
            $nickname = $this->getString('nickname', '');
            $createProject = $this->getString('createProject', 0);
            $modifyUser = $this->getString('modifyUser', 0);

            UserService::editOtherUser($this->user_id,$userId, $department, $workgroup,
                $realname,$avatar, $nickname,$createProject,$modifyUser);
            $url = YUrl::createFrontendUrl('Index', 'close');
            $this->success('修改成功', $url, 2);
        }
    }
    /**
     * 信息修改。
     */
    public function editSelfInfoAction()
    {
        if ($this->_request->isPost()) {
            $department = $this->getInt('department', '');
            $workgroup = $this->getInt('workgroup', '');
//            $realname = $this->getString('realname', '');
            $avatar = $this->getString('avatar', '');
            $nickname = $this->getString('nickname', '');
            $createProject = $this->getString('createProject', 0);
            $modifyUser = $this->getString('modifyUser', 0);

            UserService::editUser($this->user_id, $department, $workgroup,
                $avatar, $nickname,$createProject,$modifyUser);
            $url = YUrl::createFrontendUrl('Index', 'close');
            $this->success('修改成功', $url, 2);
        }
        $userDataList = UserService::getUserDetail($this->user_id);
        $this->assign("userDataList",$userDataList);
    }

    public function getAction()
    {
        if ($this->_request->isPost()) {
            $userId = $this->getInt('userId', '');
            $userInfo = UserService::getUserDetail($userId);
            $this->assign("userInfo",$userInfo);
        }
    }

    public function addAction()
    {
        if ($this->_request->isPost()) {
            $username = $this->getString('username', '');
            $password = $this->getString('password', '');
            UserService::register($username, $password);
            $url = YUrl::createFrontendUrl('Index', 'close');
            $this->success('添加成功', $url, 2);
        }
    }
}