<?php
/**
 * 管理。
 * @author fingerQin
 * @date 2018-01-11
 */

use common\YUrl;
use services\ManhourService;
use finger\Paginator;
use common\YCore;
use services\ProjectService;
use services\TaskcoeService;
use services\UserService;
use services\RoleService;
use services\MemberService;

class manhourController extends \common\controllers\User
{
    public function indexAction()
    {
        if ($this->getGP("projectId")==null) {
            $projectList        = ProjectService::getProjectList($where = []);
            $this->assign("projectList",$projectList);
        }
        else{
            $projectId = $this->getInt('projectId', '');
            $projectNickname = ProjectService::getNickname($projectId);
            $manhourList        = ManhourService::getManhourList($projectNickname);
            foreach ($manhourList as &$manhour){
                $taskcoeId = $manhour['taskcoe_id'];
                $taskcoe = TaskcoeService::getTaskcoeById($projectNickname,$taskcoeId);
                $manhour["taskcoe"] = $taskcoe;
                $manhour["auditUser"] = UserService::getUserDetail($manhour["audit_user_id"]);
                $manhour["finishUser"] = UserService::getUserDetail($manhour["user_id"]);
            }
            unset($manhour);
            $this->assign("projectId",$projectId);
            $this->assign("manhourList",$manhourList);
        }
    }
    /**
     * 新建工时。
     */
    public function createAction()
    {
        if ($this->_request->isPost()) {
            $projectId = $this->getInt("projectId");
            $taskcoeId = $this->getInt("taskcoeId");
            $workContent = $this->getString("workContent");
            $manhour = $this->getFloat("manhour");
            $overtimeManhour = $this->getFloat("overtimeManhour");
            $workdate = $this->getDate("workdate");
            $auditUserId = $this->getInt("auditUserId");
            $projectNickname = ProjectService::getNickname($projectId);
            ManhourService::createManhour($projectNickname,$this->user_id,$taskcoeId,$workContent,$manhour,$overtimeManhour,$workdate,$auditUserId);
            $url = YUrl::createFrontendUrl('Index', 'close');
            $this->success('工时信息添加成功', $url, 2);
        }
        else{
            $projectId = $this->getInt("projectId");
            $projectNickname = ProjectService::getNickname($projectId);
            $taskcoeList = TaskcoeService::getTaskcoeList($projectNickname);
            $auditList = MemberService::getauditList($this->user_id,$projectNickname);
            $this->assign("auditList",$auditList);
            $this->assign("taskcoeList",$taskcoeList);
        }
    }

    public function deleteAction()
    {
        if ($this->_request->isPost()) {
            $projectId = $this->getInt("projectId");
            $projectNickname = ProjectService::getNickname($projectId);
            $manhourId = $this->getInt("manhourId");
            ManhourService::removeManhour($projectNickname,$this->user_id,$manhourId);
            $url = YUrl::createFrontendUrl('Index', 'close');
            $this->success('工时信息删除成功', $url, 2);
        }
        $projectId = $this->getGP('projectId');
        $this->assign("projectId",$projectId);
    }

    public function deleteAllAction()
    {
        if ($this->_request->isPost()) {
            $projectId = $this->getInt("projectId");
            $manhourIds = $this->getString("manhourId");
            $manhourIds = explode(",",$manhourIds);
            $projectNickname = ProjectService::getNickname($projectId);
            foreach ($manhourIds as $manhourId){
                ManhourService::removeManhour($projectNickname,$this->user_id,$manhourId);
            }
            $url = YUrl::createFrontendUrl('Index', 'close');
            $this->success('工时信息删除成功', $url, 2);
        }
        $projectId = $this->getGP('projectId');
        $this->assign("projectId",$projectId);
    }

    public function editAction()
    {
        if ($this->_request->isPost()) {
            $projectId = $this->getInt("projectId");
            $manhourId = $this->getInt("manhourId");
            $taskcoeId = $this->getInt("taskcoeId");
            $workContent = $this->getString("workContent");
            $manhour = $this->getFloat("manhour");
            $overtimeManhour = $this->getFloat("overtimeManhour");
            $workdate = $this->getDate("workdate");
            $auditUserId = $this->getInt("auditUserId");
            $projectNickname = ProjectService::getNickname($projectId);
            ManhourService::editManhour($projectNickname,$this->user_id,$taskcoeId,$workContent,$manhour,$overtimeManhour,$workdate,$auditUserId,$manhourId);
            $url = YUrl::createFrontendUrl('Index', 'close');
            $this->success('工时信息编辑成功', $url, 2);
        }
        else{
            $projectId = $this->getInt("projectId");
            $projectNickname = ProjectService::getNickname($projectId);
            $taskcoeList = TaskcoeService::getTaskcoeList($projectNickname);
            $auditList = MemberService::getauditList($this->user_id,$projectNickname);
            $this->assign("auditList",$auditList);
            $this->assign("taskcoeList",$taskcoeList);
        }
    }

    public function auditedAction()
    {
        if ($this->getGP("projectId")==null) {
            $projectList        = ProjectService::getProjectList($where = []);
            $this->assign("projectList",$projectList);
        }
        else{
            $projectId = $this->getInt('projectId', '');
            $projectNickname = ProjectService::getNickname($projectId);
            $manhourList        = ManhourService::getManhourList($projectNickname);
            $unAuditManhourList = [];
            foreach ($manhourList as $manhour){
                if($manhour["audit_user_id"]==$this->user_id&&$manhour["is_audit"]==1)
                {
                    $taskcoeId = $manhour['taskcoe_id'];
                    $taskcoe = TaskcoeService::getTaskcoeById($projectNickname,$taskcoeId);
                    $manhour["taskcoe"] = $taskcoe;
                    $manhour["auditUser"] = UserService::getUserDetail($manhour["audit_user_id"]);
                    $manhour["finishUser"] = UserService::getUserDetail($manhour["user_id"]);
                    $unAuditManhourList[] = $manhour;
                }
            }
            $this->assign("projectId",$projectId);
            $this->assign("unAuditManhourList",$unAuditManhourList);
        }
    }

    public function auditAction()
    {
        if ($this->_request->isPost()) {
            $projectId = $this->getInt("projectId");
            $manhourId = $this->getInt("manhourId");
            $taskcoeValue = $this->getFloat("taskcoeValue");
            $effciencyCoe = $this->getFloat("effciencyCoe");
            $isFact = $this->getString("isFact");
            $qualityCoe = $this->getFloat("qualityCoe");
            $projectNickname = ProjectService::getNickname($projectId);
            ManhourService::auditManhour($projectNickname,$this->user_id,$manhourId,$taskcoeValue,$effciencyCoe,$isFact,$qualityCoe);
            $url = YUrl::createFrontendUrl('Index', 'close');
            $this->success('工时信息审核成功', $url, 2);
        }
    }

    public function auditAllAction()
    {
        if ($this->_request->isPost()) {
            $projectId = $this->getInt("projectId");
            $manhourIds = $this->getString("manhourId");
            foreach (explode(",",$manhourIds) as $manhourId){
                $projectNickname = ProjectService::getNickname($projectId);
                $manhour = ManhourService::getManhour($projectNickname,$manhourId);
                $taskcoe = TaskcoeService::getTaskcoeById($projectNickname,$manhour["taskcoe_id"]);
                $taskcoeValue = $taskcoe["recommend_taskcoe_value"];
                $effciencyCoe = 1;
                $isFact = 1;
                $qualityCoe = 1;
                ManhourService::auditManhour($projectNickname,$this->user_id,$manhourId,$taskcoeValue,$effciencyCoe,$isFact,$qualityCoe);
            }
            $url = YUrl::createFrontendUrl('Index', 'close');
            $this->success('工时信息审核成功', $url, 2);
        }
        $projectId = $this->getGP('projectId');
        $this->assign("projectId",$projectId);
    }

    public function rejectAction()
    {
        if ($this->_request->isPost()) {
            $projectId = $this->getInt("projectId");
            $manhourId = $this->getInt("manhourId");
            $projectNickname = ProjectService::getNickname($projectId);
            ManhourService::rejectManhour($projectNickname,$this->user_id,$manhourId);
            $url = YUrl::createFrontendUrl('Index', 'close');
            $this->success('工时信息退回成功', $url, 2);
        }
        $projectId = $this->getGP('projectId');
        $this->assign("projectId",$projectId);
    }

    public function unAuditAction()
    {
        if ($this->getGP("projectId")==null) {
            $projectList        = ProjectService::getProjectList($where = []);
            $this->assign("projectList",$projectList);
        }
        else{
            $projectId = $this->getInt('projectId', '');
            $projectNickname = ProjectService::getNickname($projectId);
            $manhourList        = ManhourService::getManhourList($projectNickname);
            $unAuditManhourList = [];
            foreach ($manhourList as $manhour){
                if($manhour["audit_user_id"]==$this->user_id&&$manhour["is_audit"]==0)
                {
                    $taskcoeId = $manhour['taskcoe_id'];
                    $taskcoe = TaskcoeService::getTaskcoeById($projectNickname,$taskcoeId);
                    $manhour["taskcoe"] = $taskcoe;
                    $manhour["auditUser"] = UserService::getUserDetail($manhour["audit_user_id"]);
                    $manhour["finishUser"] = UserService::getUserDetail($manhour["user_id"]);
                    $unAuditManhourList[] = $manhour;
                }
            }
            $this->assign("projectId",$projectId);
            $this->assign("unAuditManhourList",$unAuditManhourList);
        }
    }

    public function getAction()
    {
        if ($this->_request->isPost()) {
            $projectId = $this->getInt('projectId', '');
            $projectNickname =ProjectService::getNickname($projectId);
            $ManhourList = ManhourService::getManhourList($projectNickname);
            $this->assign("ManhourList",$ManhourList);
        }
    }

    public function getManhourAction()
    {
        if ($this->_request->isPost()) {
            $projectId = $this->getInt('projectId', '');
            $projectNickname =ProjectService::getNickname($projectId);
            $manhourId = $this->getInt("manhourId");
            $manhourInfo = ManhourService::getManhour($projectNickname,$manhourId);


            $this->assign("manhourInfo",$manhourInfo);
        }
    }
}