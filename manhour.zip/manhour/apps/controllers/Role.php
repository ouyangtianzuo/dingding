<?php
/**
 * 项目管理。
 * @author fingerQin
 * @date 2018-01-11
 */

use services\RoleService;
use services\ProjectService;
use common\YUrl;

class RoleController extends \common\controllers\User
{
    public function indexAction()
    {
        if ($this->getGP("projectId")==null){
            $projectList = ProjectService::getProjectList($where = []);
            $this->assign("projectList",$projectList);
        }
        else {
            $projectId = $this->getInt('projectId', '');
            $roleList        = RoleService::getRoleList(ProjectService::getNickname($projectId));
            $this->assign("roleList",$roleList);
            $this->assign("projectId",$projectId);
        }
    }

    public function viewAction()
    {
        $projectId = $this->getInt('projectId', '');
        $roleId = $this->getInt('roleId', '');
        $projectNickname = ProjectService::getNickname($projectId);
        $role = RoleService::getRole($this->user_id,$projectNickname,$roleId);
        $this->assign("role",$role);
    }

    public function createAction()
    {
        if ($this->_request->isPost()) {
            $projectId = $this->getInt('projectId', '');
            $roleName = $this->getString('roleName', '');
            $manageMember = $this->getBool('manageMember', 0);
            $manageRole = $this->getBool('manageRole', 0);
            $manageProject = $this->getBool('manageProject', 0);
            $manageTaskcoe = $this->getBool('manageTaskCoe', 0);
            $auditManhour = $this->getBool('auditManhour', 0);
            $consultManhour = $this->getBool('consultManhour', 0);
            $createManhour = $this->getBool('createManhour', 0);
            $deleteManhour = $this->getBool('deleteManhour', 0);
            $projectNickname = ProjectService::getNickname($projectId);//            var_dump($manageMember);
            RoleService::addRole($this->user_id,$projectNickname,$roleName,$manageProject,$manageMember,$manageRole,
                $manageTaskcoe,$auditManhour,$consultManhour,$createManhour,$deleteManhour);
            $url = YUrl::createFrontendUrl('Index', 'close');
            $this->success('角色添加成功', $url, 3);
        }
        $projectList        = ProjectService::getProjectList($where = []);
        $this->assign("projectList",$projectList);
    }

    public function deleteAction()
    {
        if ($this->_request->isPost()) {

            $projectId = $this->getInt('projectId', '');
            $projectNickname = ProjectService::getNickname($projectId);
            $roleId = $this->getInt('roleId', '');
            RoleService::deleteRole($this->user_id,$projectNickname,$roleId);
            $url = YUrl::createFrontendUrl('Index', 'close');
            $this->success('角色删除成功', $url, 2);
        }
    }

    /**
     * 项目信息删除首页。
     */
    public function deleteAllAction()
    {
        if ($this->_request->isPost()) {
            $projectId = $this->getInt('projectId', '');
            $roleIds = $this->getString('roleId', '');
            $roleIds = explode(',',$roleIds);
            $projectNickname = ProjectService::getNickname($projectId);
            foreach ($roleIds as $roleId){
                RoleService::deleteRole($this->user_id,$projectNickname,$roleId);
            }
            $url = YUrl::createFrontendUrl('Index', 'close');
            $this->success('角色删除成功', $url, 2);
        }
    }

    public function editAction()
    {
        if ($this->_request->isPost()) {
            $projectId = $this->getInt('projectId', '');
            $roleId = $this->getInt('roleId', '');
            $roleName = $this->getString('roleName', 0);
            $manageProject = $this->getBool('manageProject', 0);
            $manageMember = $this->getBool('manageMember', 0);
            $manageRole = $this->getBool('manageRole', 0);
            $manageTaskcoe = $this->getBool('manageTaskCoe', 0);
            $auditManhour = $this->getBool('auditManhour', 0);
            $consultManhour = $this->getBool('consultManhour', 0);
            $createManhour = $this->getBool('createManhour', 0);
            $deleteManhour = $this->getBool('deleteManhour', 0);
            $projectNickname = ProjectService::getNickname($projectId);
            RoleService::editRole($this->user_id,$projectNickname,$roleName,$manageProject,$manageMember,$manageRole,
                $manageTaskcoe,$auditManhour,$consultManhour,$createManhour,$deleteManhour,$roleId);
            $url = YUrl::createFrontendUrl('Index', 'close');
            $this->success('角色修改成功', $url, 2);
        }
        $projectList = ProjectService::getProjectList($where = []);
        $this->assign("projectList",$projectList);
    }

    public function getAction()
    {
        if ($this->_request->isPost()) {
            $projectId = $this->getInt('projectId', '');
            $projectNickname =ProjectService::getNickname($projectId);
            $roleList = RoleService::getRoleList($projectNickname);
            $this->assign("roleList",$roleList);
        }
    }

    public function getroleAction()
    {
        if ($this->_request->isPost()) {
            $projectId = $this->getInt('projectId', '');
            $projectNickname =ProjectService::getNickname($projectId);
            $roleId = $this->getInt('roleId', '');
            $role = RoleService::getRole($this->user_id,$projectNickname,$roleId);
            $this->assign("role",$role);
        }
    }

}




