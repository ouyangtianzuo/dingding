<?php
/**
 * 项目管理。
 * @author fingerQin
 * @date 2018-01-11
 */

use services\ProjectService;
use common\YUrl;
use finger\Paginator;

class ProjectController extends \common\controllers\User
{
    /**
     * 项目信息总览。
     */
    public function indexAction()
    {
        $projectList        = ProjectService::getProjectList($where = []);
        $this->assign("projectList",$projectList);
    }
    /**
     * 项目创建（默认创建人为项目创建者）。
     */
    public function createAction()
    {
        if ($this->_request->isPost()) {
            $projectName = $this->getString('projectName', '');
            $projectStatus = $this->getString('projectStatus', '');
            $projectType = $this->getString('projectType', '');
            $projectNickname = $this->getString('projectNickname', '');
            ProjectService::createProject($this->user_id,$projectName,$projectStatus,$projectType,$projectNickname);
            $url = YUrl::createFrontendUrl('Index', 'close');
            $this->success('项目创建成功', $url, 2);
        }
    }
    /**
     * 项目信息编辑首页（含工作内容系数编辑）。
     */
    public function editAction()
    {
        if ($this->_request->isPost()) {
            $projectId = $this->getInt('projectId', '');
            $projectName = $this->getString('projectName', '');
            $projectStatus = $this->getString('projectStatus', '');
            $projectType = $this->getString('projectType', '');
//            var_dump($this->user_id);
            ProjectService::editProject($this->user_id,$projectId,$projectName,$projectType,$projectStatus);
//            var_dump($this->user_id);
            $url = YUrl::createFrontendUrl('Index', 'close');
            $this->success('项目信息修改成功', $url, 2);
        }
        else
        {
            $projectList        = ProjectService::getProjectList($where = []);
            $this->assign("projectList",$projectList);
        }
    }

    /**
     * 项目信息删除首页。
     */
    public function deleteAction()
    {
        if ($this->_request->isPost()) {
            $projectId = $this->getInt('projectId', '');
            ProjectService::deleteProject($this->user_id,$projectId);
            $url = YUrl::createFrontendUrl('Index', 'close');
            $this->success('项目删除成功', $url, 2);
        }
    }
    /**
    * 项目信息删除首页。
    */
    public function deleteAllAction()
    {
        if ($this->_request->isPost()) {
            $projectIds = $this->getString('projectId', '');
            $projectIds = explode(',',$projectIds);
            foreach ($projectIds as $projectId){
                ProjectService::deleteProject($this->user_id,$projectId);
            }
            $url = YUrl::createFrontendUrl('Index', 'close');
            $this->success('项目删除成功', $url, 2);
        }
    }

    /**
     * 项目工时系数编辑首页。
     */
    public function viewTaskcoeAction()
    {
        if ($this->_request->isPost()) {
            $projectId = $this->getInt('projectId', '');
            $projectName = ProjectService::getName($projectId);
            $taskcoe = ProjectService::getProjectTaskCoe($projectId);
            $this->assign("projectId",$projectId);
            $this->assign("projectName",$projectName);
            $this->assign("taskcoe",$taskcoe);
        }
        $projectList        = ProjectService::getProjectList($where = []);
        $this->assign("projectList",$projectList);
    }

    /**
     * 项目工时系数编辑首页。
     */
    public function editTaskcoeAction()
    {
        if ($this->_request->isPost()) {
            $projectId = $this->getInt('projectId', '');
//            $projectId = $list["project_id"];
            $reportWrite = $this->getFloat('reportWrite', '');
            $meetingAttend = $this->getFloat('meetingAttend', '');
            $meetingReport = $this->getFloat('meetingReport', '');
            $communicate = $this->getFloat('communicate', '');
            $checkProduce = $this->getFloat('checkProduce', '');
            ProjectService::editTaskcoe($this->user_id,$projectId, $reportWrite, $meetingAttend,$meetingReport,
                $communicate,$checkProduce);
            $url = YUrl::createFrontendUrl('Project', 'index');
            $this->success('项目工时系数编辑成功', $url, 3);
        }
    }
}