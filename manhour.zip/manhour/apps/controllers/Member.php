<?php
/**
 * 管理。
 * @author fingerQin
 * @date 2018-01-11
 */

use common\YUrl;
use services\MemberService;
use services\ProjectService;
use services\RoleService;
use services\UserService;
use finger\Paginator;
use common\YCore;

class memberController extends \common\controllers\User
{
    public function indexAction()
    {
        if ($this->getGP("projectId")==null)
        {
            $projectList        = ProjectService::getProjectList($where = []);
            $this->assign("projectList",$projectList);
        }
        else{
            $projectId = $this->getInt('projectId', '');
            $memberList        = MemberService::getMemberList($this->user_id,ProjectService::getNickname($projectId));
            $this->assign("memberList",$memberList);
            $this->assign("projectId",$projectId);
        }
    }

    public function addAction()
    {
        if ($this->_request->isPost()) {
            $projectId = $this->getInt('projectId', '');
            $userId = $this->getInt('userId', '');
            $roleId = $this->getInt('roleId', '');
            $projectNickname = ProjectService::getNickname($projectId);
            MemberService::addMember($this->user_id,$userId,$projectNickname,$roleId);
            $url = YUrl::createFrontendUrl('Index', 'close');
            $this->success('成员添加成功', $url, 2);
        }
        $projectId = $this->getGP('projectId');
        $userDataList = UserService::getUserDataList()[0];
        $roleList = RoleService::getRoleList(ProjectService::getNickname($projectId));
        $this->assign("userDataList",$userDataList);
        $this->assign("roleList",$roleList);

    }

    public function editAction()
    {
        if ($this->_request->isPost()) {
            $projectId = $this->getInt('projectId', '');
            $userId = $this->getInt('userId', '');
            $roleId = $this->getInt('roleId', '');
            $projectNickname = ProjectService::getNickname($projectId);
            MemberService::editMember($this->user_id,$userId,$projectNickname,$roleId);
            $url = YUrl::createFrontendUrl('Index', 'close');
            $this->success('成员编辑成功', $url, 2);
        }
        $projectId = $this->getGP('projectId');
        $this->assign("projectId",$projectId);
        $roleList = RoleService::getRoleList(ProjectService::getNickname($projectId));
        $this->assign("roleList",$roleList);

    }

    public function removeAction()
    {
        if ($this->_request->isPost()) {
            $projectId = $this->getInt('projectId', '');
            $userId = $this->getInt('userId', '');
            $projectNickname = ProjectService::getNickname($projectId);
            MemberService::removeMember($this->user_id,$userId,$projectNickname);
            $url = YUrl::createFrontendUrl('Index', 'close');
            $this->success('成员删除成功', $url, 2);
        }
        $projectId = $this->getGP('projectId');
        $this->assign("projectId",$projectId);
    }

    public function removeAllAction()
    {
        if ($this->_request->isPost()) {
            $projectId = $this->getInt('projectId', '');
            $userIds = $this->getString('userId', '');
            $projectNickname = ProjectService::getNickname($projectId);
            $userIds = explode(',',$userIds);
            foreach ($userIds as $userId){
                MemberService::removeMember($this->user_id,$userId,$projectNickname);
            }
            $url = YUrl::createFrontendUrl('Index', 'close');
            $this->success('成员删除成功', $url, 2);
        }
        $projectId = $this->getGP('projectId');
        $this->assign("projectId",$projectId);
    }


    public function getAction()
    {
        if ($this->_request->isPost()) {
            $projectId = $this->getInt('projectId', '');
            $projectNickname =ProjectService::getNickname($projectId);

            $list    = UserService::getUserList();
            $addmemberList = MemberService::getnotinProject($projectNickname,$list);
            $memberList = MemberService::getMemberList(ProjectService::getNickname($projectId));
            $auditList = MemberService::getauditList($projectNickname);
            $result = [
                'addmemberList'  => $addmemberList,
                'memberList'  => $memberList,
                'auditList'  => $auditList
            ];

            $this->assign("result",$result);
        }
    }

    public function getmemberAction()
    {
        if ($this->_request->isPost()) {
            $projectId = $this->getInt('projectId', '');
            $projectNickname =ProjectService::getNickname($projectId);
            $userId = $this->getInt('userId', '');
            $memberinfo = MemberService::getMember($projectNickname,$userId);

            $this->assign("memberinfo",$memberinfo);
        }
    }


}