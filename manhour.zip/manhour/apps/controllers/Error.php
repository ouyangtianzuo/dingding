<?php
/**
 * 错误处理控制器。
 * @author fingerQin
 * @date 2015-11-13
 */

class ErrorController extends \common\controllers\Error
{

}