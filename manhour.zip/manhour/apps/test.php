?php
/**
 * Created by PhpStorm.
 * User: chenf
 * Date: 2018/9/19
 * Time: 17:34
 */
echo uniqid('mp');
?>