<?php
use common\YUrl;
use common\YCore;
?>

<!doctype html>
<html lang="en">

<?php
require_once (dirname(__DIR__) . '/common/head.php');
?>
    <body>
        <script type="text/javascript">
            parent.location.replace(parent.location.href);
            var index = parent.layer.getFrameIndex(window.name); //先得到当前iframe层的索引
            parent.layer.close(index); //执行关闭
        </script>
    </body>
</html>