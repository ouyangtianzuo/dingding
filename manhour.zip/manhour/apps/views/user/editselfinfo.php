<?php
use common\YUrl;
use common\YCore;
require_once (dirname(__DIR__) . '/common/head.php');
//require_once (dirname(__DIR__) . '/common/left.php');
?>
    <form class="layui-form" method="POST" action="">
        <div class="layui-form-item">
            <label class="layui-form-label">科室</label>
            <div class="layui-input-inline">
                <input type="text" name="department" required lay-verify="required" placeholder="<?php echo $userDataList['department']?>" autocomplete="off" class="layui-input">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">工程组</label>
            <div class="layui-input-inline">
                <input type="text" name="workgroup" required lay-verify="required" placeholder="<?php echo $userDataList['workgroup']?>" autocomplete="off" class="layui-input">
            </div>
        </div>
<!--        <div class="layui-form-item">-->
<!--            <label class="layui-form-label">真实姓名</label>-->
<!--            <div class="layui-input-inline">-->
<!--                <input type="text" name="realname" required lay-verify="required" placeholder="--><?php //echo $userDataList['realname']?><!--" autocomplete="off" class="layui-input">-->
<!--            </div>-->
<!--        </div>-->
        <div class="layui-form-item">
            <label class="layui-form-label">头像地址</label>
            <div class="layui-input-inline">
                <input type="text" name="avatar" required lay-verify="required" placeholder="<?php echo $userDataList['avatar']?>" autocomplete="off" class="layui-input">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">昵称</label>
            <div class="layui-input-inline">
                <input type="text" name="nickname" required lay-verify="required" placeholder="<?php echo $userDataList['nickname']?>" autocomplete="off" class="layui-input">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">创建项目</label>
            <div class="layui-input-block">
                <input type="checkbox" name="createProject" value="1" lay-skin="switch" lay-text="允许|不允许"">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">用户修改</label>
            <div class="layui-input-block">
                <input type="checkbox" name="modifyUser" value="1" lay-skin="switch" lay-text="允许|不允许"">
            </div>
        </div>
        <div class="layui-form-item">
            <div class="layui-input-block">
                <button class="layui-btn" lay-submit lay-filter="formDemo">立即提交</button>
            </div>
        </div>
    </form>

    <script>
        layui.use('form', function(){
            var form = layui.form;
        });
    </script>

