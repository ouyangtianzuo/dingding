<?php
use common\YUrl;
use common\YCore;
require_once (dirname(__DIR__) . '/common/top.php');
require_once (dirname(__DIR__) . '/common/left.php');
?>

    <style>
        .loginDiv {
            clear:both;
            margin: 200px auto;
            width: 500px;
        }
        .layui-input {
            width: 300px;
        }
    </style>
    <div class="loginDiv">
        <?php foreach ($userinfo as $key=>$info):?>
            <h1 class="site-h1"><?php echo $key; ?></h1>
            <div class="site-content-doc">
                <?php echo $info; ?>
            </div>
        <?php endforeach;?>
    </div>
<?php
require_once (dirname(__DIR__) . '/common/footer.php');
?>