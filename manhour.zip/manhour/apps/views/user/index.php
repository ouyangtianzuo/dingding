<?php
use common\YUrl;
use common\YCore;
require_once (dirname(__DIR__) . '/common/head.php');
?>

<body>
<div class="weadmin-body">
    <div class="weadmin-block">
<!--        <button class="layui-btn layui-btn-danger" onclick="deleteAll()"><i class="layui-icon"></i>批量删除</button>-->
        <button class="layui-btn" onclick="WeAdminShow('添加用户','/User/Add',460,400)"><i class="layui-icon"></i>添加用户</button>
        <button class="layui-btn" onclick="location.replace(location.href);"><i class="layui-icon">&#x1002;</i>刷新</button>
        <span class="fr" style="line-height:40px">共有用户：<?php echo count($userDataList)?> 个</span>
    </div>
    <table class="layui-table" id="UserDataList">
        <thead>
        <tr>
            <th>
                <div class="layui-unselect header layui-form-checkbox" lay-skin="primary"><i class="layui-icon">&#xe605;</i></div>
            </th>
            <th>用户ID</th>
            <th>用户名</th>
            <th>科室</th>
            <th>组别</th>
            <th>真实姓名</th>
            <th>头像地址</th>
            <th>昵称</th>
            <th>新建项目权限</th>
            <th>修改用户信息权限</th>
            <th>操作</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($userDataList as $key=>$userData): ?>
            <tr data-id="<?php echo $userData['user_id']?>">
                <td>
                    <div class="layui-unselect layui-form-checkbox" lay-skin="primary" data-id="<?php echo $userData['user_id']?>"><i class="layui-icon">&#xe605;</i></div>
                </td>
                <td><?php echo $userData['user_id']?></td>
                <td><?php echo $userList[$key]['username']?></td>
                <td><?php echo $userData['department']?></td>
                <td><?php echo $userData['workgroup']?></td>
                <td><?php echo $userData['realname']?></td>
                <td><?php echo $userData['avatar']?></td>
                <td><?php echo $userData['nickname']?></td>
                <td class="td-status">
                    <?php
                    if ($userData['create_project']==1):
                        $statusBtnType = 'layui-btn';
                    else:
                        $statusBtnType = 'layui-btn-danger';
                    endif;
                    ?>
                    <span class="layui-btn <?php echo $statusBtnType?> layui-btn-xs">
                        <?php echo $userData['create_project']==1?"允许":"不允许"?>
                    </span>
                </td>
                <td class="td-status">
                    <?php
                    if ($userData['modify_user']==1):
                        $statusBtnType = 'layui-btn';
                    else:
                        $statusBtnType = 'layui-btn-danger';
                    endif;
                    ?>
                    <span class="layui-btn <?php echo $statusBtnType?> layui-btn-xs">
                        <?php echo $userData['modify_user']==1?"允许":"不允许"?>
                    </span>
                </td>
                <td class="td-manage">
                    <a title="编辑" onclick="WeAdminEdit('编辑','/User/EditOtherInfo', <?php echo $userData['user_id']?>, 600, 400)" href="javascript:;">
                        <i class="layui-icon">&#xe642;</i>
                    </a>
<!--                    <a title="删除" onclick="WeAdminEdit('删除','/User/Delete', <?php //echo $userData['user_id']?>////, 600, 400)" href="javascript:;">-->
<!--                        <i class="layui-icon">&#xe640;</i>-->
<!--                    </a>-->
                </td>
            </tr>
        <?php endforeach;?>
        </tbody>
    </table>
    <div class="page">
        <div>
            <a class="prev" href="">&lt;&lt;</a>
            <a class="num" href="">1</a>
            <span class="current">2</span>
            <a class="num" href="">3</a>
            <a class="num" href="">489</a>
            <a class="next" href="">&gt;&gt;</a>
        </div>
    </div>

</div>
<script>
    window.deleteAll = function (obj, id) {
        var data = tableCheck.getData();
        WeAdminEdit('批量删除','/Project/DeleteAll', data, 600, 400);
    }
</script>
<script src="<?php echo YUrl::assets('js','/layui/layui.js')?>" charset="utf-8"></script>
<script src="<?php echo YUrl::assets('js','/eleDel.js')?>" type="text/javascript" charset="utf-8"></script>
</body>

</html>