<?php
echo json_encode($userList);
?>
