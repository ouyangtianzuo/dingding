<?php
use common\YUrl;
use common\YCore;
require_once (dirname(__DIR__) . '/common/head.php');
//require_once (dirname(__DIR__) . '/common/left.php');
?>
<!DOCTYPE html>
<html>

<body>
<div class="weadmin-body">
    <form class="layui-form" method="post">
        <div class="layui-form-item">
            <label for="L_pass" class="layui-form-label">
                <span class="we-red">*</span>原密码
            </label>
            <div class="layui-input-inline">
                <input type="password" id="L_oldPwd" name="oldPwd" lay-verify="required" autocomplete="off" class="layui-input">
            </div>
            <div class="layui-form-mid layui-word-aux">
            </div>
        </div>
        <div class="layui-form-item">
            <label for="L_repass" class="layui-form-label">
                <span class="we-red">*</span>新密码
            </label>
            <div class="layui-input-inline">
                <input type="password" id="L_newPwd" name="newPwd" lay-verify="required" autocomplete="off" class="layui-input">
            </div>
        </div>
        <div class="layui-form-item">
            <label for="L_repass" class="layui-form-label">
                <span class="we-red">*</span>确认密码
            </label>
            <div class="layui-input-inline">
                <input type="password" id="L_repass" lay-verify="required|repass" autocomplete="off" class="layui-input">
            </div>
        </div>
        <div class="layui-form-item">
            <label for="L_repass" class="layui-form-label">
            </label>
            <button class="layui-btn" lay-filter="add" lay-submit="">确定</button>
        </div>
    </form>
</div>
<script src="<?php echo YUrl::assets('js','/layui/layui.js')?>" charset="utf-8"></script>
<script type="text/javascript">
    layui.extend({
        admin: '<?php echo YUrl::assets('js','admin')?>'
    });
    layui.use(['form', 'jquery', 'admin','layer'], function() {
        var form = layui.form,
            $ = layui.jquery,
            admin = layui.admin,
            layer = layui.layer;

        //自定义验证规则
        form.verify({
            repass: function(value) {
                if ($("#L_newPwd").val()!=value)
                {
                    return '两次输入的密码不一致！'
                }
            }
        });
    });
</script>
</body>

</html>