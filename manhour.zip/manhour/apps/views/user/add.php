<?php
use common\YUrl;
use common\YCore;
?>
<!DOCTYPE html>
<html>
<?php
require_once (dirname(__DIR__) . '/common/head.php');
?>
<body>
    <div class="weadmin-body">
        <form class="layui-form" method="POST" action="">
            <div class="layui-form-item">
                <label class="layui-form-label">用户名</label>
                <div class="layui-input-inline">
                    <input type="text" name="username" required  lay-verify="required" placeholder="用户名" autocomplete="off" class="layui-input">
                </div>
            </div>
            <div class="layui-form-item">
                <label class="layui-form-label">密码</label>
                <div class="layui-input-inline">
                    <input name="password" required  type="password" lay-verify="required" placeholder="密码" class="layui-input">
                </div>
            </div>
            <div class="layui-form-item">
                <div class="layui-input-block">
                <button class="layui-btn" lay-submit lay-filter="formDemo">立即提交</button>
                </div>
            </div>
        </form>
    </div>
    
    <script>
    layui.use('form', function(){
        var form = layui.form;
    });
    </script>
</div>
</body>
</html>
