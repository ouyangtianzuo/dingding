<?php
echo json_encode($userInfo);
?>
