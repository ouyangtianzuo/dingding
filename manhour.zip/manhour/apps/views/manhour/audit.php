<?php
use common\YUrl;
use common\YCore;
?>

<!DOCTYPE html>
<html>

<?php
require_once (dirname(__DIR__) . '/common/head.php');
?>

<body>
<div class="weadmin-body">
    <form class="layui-form" method="post" lay-fliter="form">
        <div class="layui-form-item">
            <label class="layui-form-label">工时系数</label>
            <div class="layui-input-inline">
                <input type="text" name="taskcoeValue" required  lay-verify="required" placeholder="工时系数" autocomplete="off" class="layui-input">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">效率系数</label>
            <div class="layui-input-inline">
                <input type="text" name="effciencyCoe" required  lay-verify="required" placeholder="效率系数" autocomplete="off" class="layui-input">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">完成度</label>
            <div class="layui-input-inline">
                <input type="text" name="qualityCoe" required  lay-verify="required" placeholder="完成度" autocomplete="off" class="layui-input">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">真实度</label>
            <div class="layui-input-inline">
                <input type="text" name="isFact" required  lay-verify="required" placeholder="真实度" autocomplete="off" class="layui-input">
            </div>
        </div>
        <div class="layui-form-item">
            <div class="layui-input-inline">
                <input type="hidden" name="manhourId" id="dataId" value="" />
            </div>
        </div>
        <div class="layui-form-item">
            <div class="layui-input-block">
                <button class="layui-btn" lay-submit lay-filter="formDemo">立即提交</button>
            </div>
        </div>
    </form>
</div>
<script src="<?php echo YUrl::assets('js','/layui/layui.js')?>" charset="utf-8"></script>
<script type="text/javascript">
    layui.use(['form','jquery'], function() {
        var form = layui.form;
        var $ = layui.jquery;
        setTimeout(function () {
            var data = $("input[id='dataId']")[0].value;
            console.log(data);
            data = data.split("|");
            var manhourId = data[0];
            var minManhourValue = data[1];
            var maxManhourValue = data[2];
            var recommondManhourValue = data[3];
            console.log(recommondManhourValue);
            $("[name='manhourId']").attr("value",manhourId);
            $("[name='taskcoeValue']").attr("placeholder",minManhourValue+"~"+maxManhourValue+",推荐"+recommondManhourValue);
        },100)
    });
</script>
</body>

</html>
