<?php
use common\YUrl;
use common\YCore;
?>

<!DOCTYPE html>
<html>

<?php
require_once (dirname(__DIR__) . '/common/head.php');
?>

<body>
<div class="weadmin-body">
    <form class="layui-form" method="POST" action="">
        <div class="layui-form-item">
            <label class="layui-form-label">工作类型</label>
            <div class="layui-input-inline">
                <select name="taskcoeId" class="layui-select" lay-filter="projectId">
                    <?php foreach ($taskcoeList as $taskcoe):?>
                        <option value="<?php echo $taskcoe["taskcoe_id"]?>"><?php echo $taskcoe["taskcoe_name"]?></option>
                    <?php endforeach ?>
                </select>
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">工作内容</label>
            <div class="layui-input-inline">
                <textarea name="workContent" required  lay-verify="required" placeholder="工作内容" autocomplete="off" class="layui-textarea"></textarea>
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">占用工时</label>
            <div class="layui-input-inline">
                <input type="text" name="manhour" required  lay-verify="required" placeholder="占用工时" autocomplete="off" class="layui-input">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">加班工时</label>
            <div class="layui-input-inline">
                <input type="text" name="overtimeManhour" required  lay-verify="required" placeholder="加班工时" autocomplete="off" class="layui-input">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">工作日期</label>
            <div class="layui-input-inline">
                <input type="text" name="workdate" id="workdate" required  lay-verify="required" placeholder="yyyy-MM-dd" autocomplete="off" class="layui-input">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">审核人</label>
            <div class="layui-input-inline">
                <select name="auditUserId" class="layui-select" lay-filter="projectId">
                    <?php foreach ($auditList as $audit):?>
                        <option value="<?php echo $audit["user_id"]?>"><?php echo $audit["realname"]?></option>
                    <?php endforeach ?>
                </select>
            </div>
        </div>
        <div class="layui-form-item">
            <div class="layui-input-bolck">
                <input type="hidden" name="manhourId" id="dataId" value="" />
            </div>
        </div>
        <div class="layui-form-item">
            <div class="layui-input-block">
                <button class="layui-btn" lay-submit lay-filter="formDemo">立即提交</button>
            </div>
        </div>
    </form>
</div>
<script src="<?php echo YUrl::assets('js','/layui/layui.js')?>" charset="utf-8"></script>
<script type="text/javascript">
    layui.use(['form','laydate'], function(){
        var form = layui.form;
        var laydate = layui.laydate;
        console.log(laydate);
        //常规用法
        laydate.render({
            elem: '#workdate'
        });
    });
</script>
</body>

</html>