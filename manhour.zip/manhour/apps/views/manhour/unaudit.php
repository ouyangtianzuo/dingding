<html lang="en">
<?php
use common\YUrl;
use common\YCore;
require_once (dirname(__DIR__) . '/common/head.php');
require_once (dirname(__DIR__) . '/common/showbooltd.php');
?>

<body>
<?php if(!isset($unAuditManhourList)):?>
    <?php
    require_once (dirname(__DIR__) . '/common/projectchoice.php');
    ?>
<?php else: ?>
    <div class="weadmin-body">
        <div class="weadmin-block">
            <button class="layui-btn layui-btn-danger" onclick="auditAll()"><i class="layui-icon"></i>批量审核</button>
            <button class="layui-btn" onclick="location.replace(location.href);"><i class="layui-icon">&#x1002;</i>刷新</button>
            <span class="fr" style="line-height:40px">共有工时信息：<?php echo count($unAuditManhourList)?> 个</span>
        </div>
        <table class="layui-table" id="manhourList">
            <thead>
            <tr>
                <th>
                    <div class="layui-unselect header layui-form-checkbox" lay-skin="primary"><i class="layui-icon">&#xe605;</i></div>
                </th>
                <th>工时信息ID</th>
                <th>完成人</th>
                <th>工作类型</th>
                <th>工作内容</th>
                <th>占用工时</th>
                <th>加班工时</th>
                <th>工作日期</th>
                <th>工时系数</th>
                <th>审核人</th>
                <th>审核状态</th>
                <th>效率系数</th>
                <th>完成度</th>
                <th>真实度</th>
                <th>操作</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($unAuditManhourList as $manhour): ?>
                <tr data-id="<?php echo $manhour['manhour_id']?>">
                    <td>
                        <div class="layui-unselect layui-form-checkbox" lay-skin="primary"
                             data-id="<?php echo $manhour['manhour_id']?>">
                            <i class="layui-icon">&#xe605;</i></div>
                    </td>
                    <td><?php echo $manhour['manhour_id']?></td>
                    <td><?php echo $manhour['finishUser']['realname']?></td>
                    <td><?php echo $manhour['taskcoe']['taskcoe_name']?></td>
                    <td><?php echo $manhour['work_content']?></td>
                    <td><?php echo $manhour['manhour']?></td>
                    <td><?php echo $manhour['over_time_manhour']?></td>
                    <td><?php echo $manhour['workdate']?></td>
                    <td><?php echo $manhour['taskcoe_value']?></td>
                    <td><?php echo $manhour['auditUser']['realname']?></td>
                    <td class="td-status">
                        <?php
                        if ($manhour['is_audit']=="0"):
                            $statusBtnType = 'layui-btn-normal';
                            $statusName = '待审核';
                        elseif ($manhour['is_audit']=="1"):
                            $statusBtnType = 'layui-btn';
                            $statusName = '审核通过';
                        elseif ($manhour['is_audit']=="2"):
                            $statusBtnType = 'layui-btn-disabled';
                            $statusName = '未通过';
                        else:
                            $statusBtnType = 'layui-btn-primary';
                            $statusName = '未知状态';
                        endif;
                        ?>
                        <span class="layui-btn <?php echo $statusBtnType?> layui-btn-xs">
                            <?php echo $statusName?>
                        </span>
                    </td>
                    <td><?php echo $manhour['effciency_coe']?></td>
                    <td><?php echo $manhour['quality_coe']?></td>
                    <td><?php echo $manhour['is_fact']?></td>
                    <td class="td-manage">
                        <a title="审批" onclick="WeAdminEdit('通过','/Manhour/audit/projectId/'+'<?php echo $projectId ?>', '<?php echo $manhour['manhour_id']
                            ."|".$manhour['taskcoe']['min_taskcoe_value']
                            ."|".$manhour['taskcoe']['max_taskcoe_value']
                            ."|".$manhour['taskcoe']['recommend_taskcoe_value']
                        ?>', 600, 400)" href="javascript:;">
                            <i class="layui-icon layui-icon-ok"></i>
                        </a>
                        <a title="退回" onclick="WeAdminEdit('退回工时','/Manhour/reject/projectId/'+'<?php echo $projectId ?>', '<?php echo $manhour['manhour_id']?>', 600, 400)" href="javascript:;">
                            <i class="layui-icon layui-icon-close"></i>
                        </a>
                    </td>
                </tr>
            <?php endforeach;?>
            </tbody>
        </table>
        <div class="page">
            <div>
                <a class="prev" href="">&lt;&lt;</a>
                <a class="num" href="">1</a>
                <span class="current">2</span>
                <a class="num" href="">3</a>
                <a class="num" href="">489</a>
                <a class="next" href="">&gt;&gt;</a>
            </div>
        </div>

    </div>
    <script>
        window.auditAll = function (obj, id) {
            var data = tableCheck.getData();
            WeAdminEdit('批量通过','/Manhour/auditAll/projectId/'+'<?php echo $projectId ?>', data, 600, 400);
        }
    </script>
<?php endif ?>
<script src="<?php echo YUrl::assets('js','/layui/layui.js')?>" charset="utf-8"></script>
<script src="<?php echo YUrl::assets('js','/eleDel.js')?>" type="text/javascript" charset="utf-8"></script>
</body>

</html>
