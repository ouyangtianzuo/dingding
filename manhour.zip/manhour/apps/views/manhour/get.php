<?php
echo json_encode($ManhourList);
?>
