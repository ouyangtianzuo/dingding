<?php
use common\YUrl;
use common\YCore;
?>
<!DOCTYPE html>
<html lang="en">
    <?php
    require_once (dirname(__DIR__) . '/common/head.php');
    ?>
    <body>
        <div class="weadmin-body">
            <form class="layui-form" method="POST" action="">
                <div class="layui-form-item">
                    <label class="layui-form-label">用户选择</label>
                    <div class="layui-input-block">
                        <select name="userId" class="layui-select" lay-filter="projectId">
                            <?php foreach ($userDataList as $userData):?>
                                <option value="<?php echo $userData["user_id"]?>"><?php echo $userData["realname"]?></option>
                            <?php endforeach ?>
                        </select>
                    </div>
                </div>
                <div class="layui-form-item">
                    <label class="layui-form-label">角色选择</label>
                    <div class="layui-input-block">
                        <select name="roleId" class="layui-select" lay-filter="projectId">
                            <?php foreach ($roleList as $role):?>
                                <option value="<?php echo $role["role_id"]?>"><?php echo $role["role_name"]?></option>
                            <?php endforeach ?>
                        </select>
                    </div>
                </div>
                <div class="layui-form-item">
                    <div class="layui-input-bolck">
                        <input type="hidden" name="projectId" id="dataId" value="" />
                    </div>
                </div>
                <div class="layui-form-item">
                    <div class="layui-input-block">
                        <button class="layui-btn" lay-submit lay-filter="formDemo">立即提交</button>
                    </div>
                </div>
            </form>
        </div>

        <script>
            layui.use('form', function(){
                var form = layui.form;
            });
        </script>
    </body>
</html>
