<?php
echo json_encode($memberinfo);
?>
