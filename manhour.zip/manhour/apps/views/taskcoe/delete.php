<?php
use common\YUrl;
use common\YCore;
require_once (dirname(__DIR__) . '/common/head.php');
?>
<body>
<div class="weadmin-body">
    <form class="layui-form" method="POST" action="" name="form">
        <div class="layui-form-item">
            <div class="layui-input-inline">
                <label class="layui-form-label">确认要删除嘛？</label>
            </div>
        </div>
        <div class="layui-form-item">
            <div class="layui-input-bolck">
                <input type="hidden" name="taskcoeId" id="dataId" value="" />
            </div>
        </div>
    </form>
    <button class="layui-btn" width="50" onclick="deleteProject()" lay-submit lay-filter="formDemo">是</button>
    <button class="layui-btn" width="50" onclick="exitDelete()" lay-submit lay-filter="formDemo">否</button>
</div>

<script>
    function deleteProject() {
        document.form.submit();
    }
    function exitDelete() {
        var index = parent.layer.getFrameIndex(window.name);
        //关闭当前frame
        parent.layer.close(index);
    }
    layui.use('form', function(){
        var form = layui.form;
    });
</script>
</body>
</html>