<?php
use common\YUrl;
use common\YCore;
?>

<!DOCTYPE html>
<html>

<?php
require_once (dirname(__DIR__) . '/common/head.php');
?>

<body>
<div class="weadmin-body">
    <form class="layui-form" method="POST" action="">
        <div class="layui-form-item">
            <label class="layui-form-label">工作类型名称</label>
            <div class="layui-input-inline">
                <input type="text" name="taskcoeName" required  lay-verify="required" placeholder="工时系数名称" autocomplete="off" class="layui-input">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">工作类型含义描述</label>
            <div class="layui-input-inline">
                <textarea type="text" name="taskcoeDescribe" required  lay-verify="required" placeholder="工时系数含义描述" autocomplete="off" class="layui-textarea"></textarea>
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">工时系数最小值</label>
            <div class="layui-input-inline">
                <input type="text" name="minTaskcoeValue" required  lay-verify="required" placeholder="工时系数最小值" autocomplete="off" class="layui-input">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">工时系数最大值</label>
            <div class="layui-input-inline">
                <input type="text" name="maxTaskcoeValue" required  lay-verify="required" placeholder="工时系数最大值" autocomplete="off" class="layui-input">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">工时系数推荐值</label>
            <div class="layui-input-inline">
                <input type="text" name="recommendTaskcoeValue" required  lay-verify="required" placeholder="工时系数推荐值" autocomplete="off" class="layui-input">
            </div>
        </div>
        <div class="layui-form-item">
            <div class="layui-input-bolck">
                <input type="hidden" name="taskcoeId" id="dataId" value="" />
            </div>
        </div>
        <div class="layui-form-item">
            <div class="layui-input-block">
                <button class="layui-btn" lay-submit lay-filter="formDemo">立即提交</button>
            </div>
        </div>
    </form>
</div>
<script src="<?php echo YUrl::assets('js','/layui/layui.js')?>" charset="utf-8"></script>
<script type="text/javascript">
    layui.use(['form','jquery'], function() {
        var form = layui.form;
    });
</script>
</body>

</html>
