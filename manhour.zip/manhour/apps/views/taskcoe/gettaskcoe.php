<?php
echo json_encode($taskcoeInfo);
?>
