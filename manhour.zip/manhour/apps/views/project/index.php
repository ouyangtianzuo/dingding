<html lang="en">

<?php
use common\YUrl;
use common\YCore;
require_once (dirname(__DIR__) . '/common/head.php');
?>

<body>
<div class="weadmin-body">
    <div class="weadmin-block">
        <button class="layui-btn layui-btn-danger" onclick="deleteAll()"><i class="layui-icon"></i>批量删除</button>
        <button class="layui-btn" onclick="WeAdminShow('添加项目','/Project/Create',460,400)"><i class="layui-icon"></i>添加项目</button>
        <button class="layui-btn" onclick="location.replace(location.href);"><i class="layui-icon">&#x1002;</i>刷新</button>
        <span class="fr" style="line-height:40px">共有项目：<?php echo count($projectList)?> 个</span>
    </div>
    <table class="layui-table" id="projectList">
        <thead>
        <tr>
            <th>
                <div class="layui-unselect header layui-form-checkbox" lay-skin="primary"><i class="layui-icon">&#xe605;</i></div>
            </th>
            <th>项目ID</th>
            <th>项目名称</th>
            <th>项目状态</th>
            <th>项目类型</th>
            <th>项目标识</th>
            <th>操作</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($projectList as $project): ?>
            <tr data-id="<?php echo $project['project_name']?>">
                <td>
                    <div class="layui-unselect layui-form-checkbox" lay-skin="primary" data-id="<?php echo $project['project_id']?>"><i class="layui-icon">&#xe605;</i></div>
                </td>
                <td><?php echo $project['project_id']?></td>
                <td><?php echo $project['project_name']?></td>
                <td class="td-status">
                    <?php
                    if ($project['project_status']=="进行"):
                        $statusBtnType = 'layui-btn-normal';
                    elseif ($project['project_status']=="结束"):
                        $statusBtnType = 'layui-btn';
                    elseif ($project['project_status']=="挂起"):
                        $statusBtnType = 'layui-btn-disabled';
                    else:
                        $statusBtnType = 'layui-btn-primary';
                    endif;
                    ?>
                    <span class="layui-btn <?php echo $statusBtnType?> layui-btn-xs">
                        <?php echo $project['project_status']?>
                    </span>
                </td>
                <td class="td-status">
                    <?php
                    if ($project['project_type']=="科研"):
                        $statusBtnType = 'layui-btn-normal';
                    elseif ($project['project_type']=="管理"):
                        $statusBtnType = 'layui-btn-warm';
                    else:
                        $statusBtnType = 'layui-btn-primary';
                    endif;
                    ?>
                    <span class="layui-btn <?php echo $statusBtnType?> layui-btn-xs">
                        <?php echo $project['project_type']?>
                    </span>
                </td>
                <td><?php echo $project['project_nickname']?></td>
                <td class="td-manage">
                    <a title="编辑" onclick="WeAdminEdit('编辑','/Project/Edit', <?php echo $project['project_id']?>, 460, 400)" href="javascript:;">
                        <i class="layui-icon">&#xe642;</i>
                    </a>
                    <a title="删除" onclick="WeAdminEdit('删除','/Project/Delete', <?php echo $project['project_id']?>, 600, 400)" href="javascript:;">
                        <i class="layui-icon">&#xe640;</i>
                    </a>
                </td>
            </tr>
        <?php endforeach;?>
        </tbody>
    </table>
    <div class="page">
        <div>
            <a class="prev" href="">&lt;&lt;</a>
            <a class="num" href="">1</a>
            <span class="current">2</span>
            <a class="num" href="">3</a>
            <a class="num" href="">489</a>
            <a class="next" href="">&gt;&gt;</a>
        </div>
    </div>

</div>
<script>
    window.deleteAll = function (obj, id) {
        var data = tableCheck.getData();
        WeAdminEdit('批量删除','/Project/DeleteAll', data, 600, 400);
    }
</script>
<script src="<?php echo YUrl::assets('js','/layui/layui.js')?>" charset="utf-8"></script>
<script src="<?php echo YUrl::assets('js','/eleDel.js')?>" type="text/javascript" charset="utf-8"></script>
</body>

</html>