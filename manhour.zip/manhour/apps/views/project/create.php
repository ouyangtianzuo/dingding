<?php
use common\YUrl;
use common\YCore;
?>
<!DOCTYPE html>
<html>
<?php
require_once (dirname(__DIR__) . '/common/head.php');
?>
<body>
    <div class="weadmin-body">
        <form class="layui-form" method="POST" action="">
            <div class="layui-form-item">
                <label class="layui-form-label">项目名称</label>
                <div class="layui-input-inline">
                <input type="text" name="projectName" required  lay-verify="required" placeholder="项目名称" autocomplete="off" class="layui-input">
                </div>
            </div>
            <div class="layui-form-item">
                <label class="layui-form-label">项目状态</label>
                <div class="layui-input-inline">
                    <select name="projectStatus" class="layui-select">
                        <option value="进行">进行</option>
                        <option value="结束">结束</option>
                        <option value="挂起">挂起</option>
                    </select>
                </div>
            </div>
            <div class="layui-form-item">
                <label class="layui-form-label">项目类型</label>
                <div class="layui-input-inline">
                    <select name="projectType" class="layui-select">
                        <option value="科研">科研</option>
                        <option value="管理">管理</option>
                    </select>
                </div>
            </div>
            <div class="layui-form-item">
                <label class="layui-form-label">项目标识</label>
                <div class="layui-input-inline">
                <input type="text" name="projectNickname" required lay-verify="required" placeholder="项目标识" autocomplete="off" class="layui-input">
                </div>
            </div>
            <div class="layui-form-item">
                <div class="layui-input-block">
                <button class="layui-btn" lay-submit lay-filter="formDemo">立即提交</button>
                </div>
            </div>
        </form>
    </div>
    
    <script>
    layui.use('form', function(){
        var form = layui.form;
    });
    </script>
</div>
</body>
</html>
