<?php
use common\YUrl;
use common\YCore;
?>

<!DOCTYPE html>
<html>

<?php
require_once (dirname(__DIR__) . '/common/head.php');
?>

<body>
<div class="weadmin-body">
    <form class="layui-form" method="post" lay-fliter="form">
        <div class="layui-form-item">
            <label class="layui-form-label">项目名称</label>
            <div class="layui-input-inline">
                <input type="text" name="projectName" required  lay-verify="required" placeholder="项目名称" autocomplete="off" class="layui-input">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">项目状态</label>
            <div class="layui-input-inline">
                <select name="projectStatus" class="layui-select">
                    <option value="进行">进行</option>
                    <option value="结束">结束</option>
                    <option value="挂起">挂起</option>
                </select>
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">项类型</label>
            <div class="layui-input-inline">
                <select name="projectType" class="layui-select">
                    <option value="科研">科研</option>
                    <option value="管理">管理</option>
                </select>
            </div>
        </div>
        <div class="layui-form-item">
            <div class="layui-input-inline">
                <input type="hidden" name="projectId" id="dataId" value="" />
            </div>
        </div>
        <div class="layui-form-item">
            <div class="layui-input-block">
                <button class="layui-btn" lay-submit lay-filter="formDemo">立即提交</button>
            </div>
        </div>
    </form>
</div>
<script src="<?php echo YUrl::assets('js','/layui/layui.js')?>" charset="utf-8"></script>
<script type="text/javascript">
    layui.use(['form','jquery'], function() {
        var form = layui.form;
        var $ = layui.jquery;
        // form.on('submit(form)', function(data) {
        //     parent.location.replace(parent.location.href);
        // })
    });
</script>
</body>

</html>
