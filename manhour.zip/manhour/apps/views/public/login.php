<?php
use common\YUrl;
?>
    <html xmlns="http://www.w3.org/1999/xhtml" lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>用户登录-工时管理系统-1.0</title>
        <meta name="renderer" content="webkit|ie-comp|ie-stand">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
        <meta http-equiv="Cache-Control" content="no-siteapp" />
        <script src="<?php echo YUrl::assets('js', '/layui/layui.js'); ?>" type="text/javascript"></script>
        <script src="<?php echo YUrl::assets('js', 'jquery-1.10.2.js'); ?>" type="text/javascript"></script>
        <link rel="shortcut icon" href="<?php echo YUrl::assets('img','favicon.ico')?>" type="image/x-icon" />
        <link rel="stylesheet" href="<?php echo YUrl::assets('css','font.css')?>">
        <link rel="stylesheet" href="<?php echo YUrl::assets('css','weadmin.css')?>" type="text/css">
        <!-- 让IE8/9支持媒体查询，从而兼容栅格 -->
        <!--[if lt IE 9]>
        <script src="https://cdn.staticfile.org/html5shiv/r29/html5.min.js"></script>
        <script src="https://cdn.staticfile.org/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>

    <body class="login-bg">

    <div class="login">
        <div class="message">工时管理系统 1.0-用户登录</div>
        <div id="darkbannerwrap"></div>

        <form method="post" class="layui-form" name="publicForm">
            <input name="username" placeholder="用户名"  type="text" lay-verify="required" class="layui-input" >
            <hr class="hr15">
            <input name="password" lay-verify="required" placeholder="密码"  type="password" class="layui-input">
            <hr class="hr15">
            <input class="loginin" onclick="publicForm.action='login'" value="登录" lay-submit lay-filter="login" style="width:49%;" action="login" type="submit">
            <input class="register"onclick="publicForm.action='register'" value="注册" lay-submit lay-filter="register" style="width:49%;" action="register" type="submit">
            <hr class="hr20" >
        </form>
    </div>
    </body>
</html>