<?php
use common\YUrl;
use common\YCore;
?>

<!DOCTYPE html>
<html>

<?php
require_once (dirname(__DIR__) . '/common/head.php');
?>

<body>
<div class="weadmin-body">
    <form class="layui-form" method="POST" action="">
        <div class="layui-form-item">
            <label class="layui-form-label">角色名称</label>
            <div class="layui-input-inline">
                <input type="text" name="roleName" required  lay-verify="required" placeholder="角色名称" autocomplete="off" class="layui-input">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">管理成员</label>
            <div class="layui-input-block">
                <input type="checkbox" name="manageMember" value="1" lay-skin="switch" lay-text="允许|不允许"">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">管理角色</label>
            <div class="layui-input-block">
                <input type="checkbox" name="manageRole" value="1" lay-skin="switch" lay-text="允许|不允许"">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">管理项目</label>
            <div class="layui-input-block">
                <input type="checkbox" name="manageProject" value="1" lay-skin="switch" lay-text="允许|不允许"">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">管理工时系数</label>
            <div class="layui-input-block">
                <input type="checkbox" name="manageTaskCoe" value="1" lay-skin="switch" lay-text="允许|不允许"">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">审核工时</label>
            <div class="layui-input-block">
                <input type="checkbox" name="auditManhour" value="1" lay-skin="switch" lay-text="允许|不允许"">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">查看工时</label>
            <div class="layui-input-block">
                <input type="checkbox" name="consultManhour" value="1" lay-skin="switch" lay-text="允许|不允许"">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">创建工时</label>
            <div class="layui-input-block">
                <input type="checkbox" name="createManhour" value="1" lay-skin="switch" lay-text="允许|不允许"">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label">删除工时</label>
            <div class="layui-input-block">
                <input type="checkbox" name="deleteManhour" value="1" lay-skin="switch" lay-text="允许|不允许"">
            </div>
        </div>
        <div class="layui-form-item">
            <div class="layui-input-bolck">
                <input type="hidden" name="projectId" id="dataId" value="" />
            </div>
        </div>
        <div class="layui-form-item">
            <div class="layui-input-bolck">
                <input type="hidden" name="roleId" value="" />
            </div>
        </div>
        <div class="layui-form-item">
            <div class="layui-input-block">
                <button class="layui-btn" lay-submit lay-filter="formDemo">立即提交</button>
            </div>
        </div>
        </form>
</div>
<script src="<?php echo YUrl::assets('js','/layui/layui.js')?>" charset="utf-8"></script>
<script type="text/javascript">
    layui.use(['form','jquery'], function() {
        var form = layui.form;
        var $ = layui.jquery;
        setTimeout(function () {
            var data = $("input[id='dataId']")[0].value;
            data = data.split("|");
            var projectId = data[0];
            var roleId = data[1];
            $("[name='projectId']").attr("value",projectId);
            $("[name='roleId']").attr("value",roleId);
        },100)
    });
</script>
</body>

</html>
