<?php
echo json_encode($roleList);
?>
