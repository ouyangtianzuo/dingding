<html lang="en">
<?php
use common\YUrl;
use common\YCore;
require_once (dirname(__DIR__) . '/common/showbooltd.php');
require_once (dirname(__DIR__) . '/common/head.php');
?>

<body>
<?php if(!isset($roleList)):?>
    <?php
    require_once (dirname(__DIR__) . '/common/projectchoice.php');
    ?>
<?php else: ?>
    <div class="weadmin-body">
        <div class="weadmin-block">
            <button class="layui-btn layui-btn-danger" onclick="deleteAll()"><i class="layui-icon"></i>批量删除</button>
            <button class="layui-btn" onclick="WeAdminEdit('添加角色','/Role/Create',<?php echo $projectId?>,460,400)"><i class="layui-icon"></i>添加角色</button>
            <button class="layui-btn" onclick="location.replace(location.href);"><i class="layui-icon">&#x1002;</i>刷新</button>
            <span class="fr" style="line-height:40px">共有角色：<?php echo count($roleList)?> 个</span>
        </div>
        <table class="layui-table" id="projectList">
            <thead>
            <tr>
                <th>
                    <div class="layui-unselect header layui-form-checkbox" lay-skin="primary"><i class="layui-icon">&#xe605;</i></div>
                </th>
                <th>角色ID</th>
                <th>角色名称</th>
                <th>管理成员</th>
                <th>管理角色</th>
                <th>管理项目</th>
                <th>管理工时系数</th>
                <th>审核工时</th>
                <th>查看工时</th>
                <th>创建工时</th>
                <th>删除工时</th>
                <th>操作</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($roleList as $role): ?>
                <tr data-id="<?php echo $role['role_id']?>">
                    <td>
                        <div class="layui-unselect layui-form-checkbox" lay-skin="primary" data-id="<?php echo $role['role_id']?>"><i class="layui-icon">&#xe605;</i></div>
                    </td>
                    <td><?php echo $role["role_id"]?></td>
                    <td><?php echo $role["role_name"]?></td>
                    <?php echo showBoolTd($role["manage_member"])?>
                    <?php echo showBoolTd($role["manage_role"])?>
                    <?php echo showBoolTd($role["manage_project"])?>
                    <?php echo showBoolTd($role["manage_taskcoe"])?>
                    <?php echo showBoolTd($role["audit_manhour"])?>
                    <?php echo showBoolTd($role["consult_manhour"])?>
                    <?php echo showBoolTd($role["create_manhour"])?>
                    <?php echo showBoolTd($role["delete_manhour"])?>
                    <td class="td-manage">
                        <a title="编辑" onclick="WeAdminEdit('编辑','/Role/Edit', '<?php echo $projectId."|".$role['role_id']?>', 600, 400)" href="javascript:;">
                            <i class="layui-icon">&#xe642;</i>
                        </a>
                        <a title="删除" onclick="WeAdminEdit('删除','/Role/Delete', '<?php echo $projectId."|".$role['role_id']?>', 600, 400)" href="javascript:;">
                            <i class="layui-icon">&#xe640;</i>
                        </a>
                    </td>
                </tr>
            <?php endforeach;?>
            </tbody>
        </table>
        <div class="page">
            <div>
                <a class="prev" href="">&lt;&lt;</a>
                <a class="num" href="">1</a>
                <span class="current">2</span>
                <a class="num" href="">3</a>
                <a class="num" href="">489</a>
                <a class="next" href="">&gt;&gt;</a>
            </div>
        </div>

    </div>
    <script>
        window.deleteAll = function (obj, id) {
            var data = <?php echo $projectId?>+"|"+tableCheck.getData();
            WeAdminEdit('批量删除','/Role/DeleteAll', data, 600, 400);
        }
    </script>
<?php endif ?>
<script src="<?php echo YUrl::assets('js','/layui/layui.js')?>" charset="utf-8"></script>
<script src="<?php echo YUrl::assets('js','/eleDel.js')?>" type="text/javascript" charset="utf-8"></script>
</body>

</html>


