<?php
echo json_encode($role);
?>
