<?php
use common\YUrl;
use common\YCore;
?>
<head>
    <meta charset="UTF-8">
    <title>工时管理系统-1.0</title>
    <meta name="renderer" content="webkit|ie-comp|ie-stand">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <meta http-equiv="Cache-Control" content="no-siteapp" />
    <link rel="shortcut icon" href="./favicon.ico" type="image/x-icon" />
    <link rel="stylesheet" href="<?php echo YUrl::assets('css','font.css')?>">
    <link rel="stylesheet" href="<?php echo YUrl::assets('js','/layui/css/layui.css')?>">
    <link rel="stylesheet" href="<?php echo YUrl::assets('css','weadmin.css')?>">
    <script type="text/javascript" src="<?php echo YUrl::assets('js','/layui/layui.js')?>" charset="utf-8"></script>
</head>