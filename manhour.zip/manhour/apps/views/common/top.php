<?php
use common\YUrl;
use common\YCore;
?>

<!-- 顶部开始 -->
<div class="container">
    <div class="logo">
        <a href="/index/index/index">工时管理系统v1.0</a>
    </div>
    <div class="left_open">
        <i title="展开左侧栏" class="iconfont">&#xe699;</i>
    </div>
    <ul class="layui-nav left fast-add" lay-filter="">
<!--        <li class="layui-nav-item">-->
<!--            <a href="javascript:;">快速入口</a>-->
<!--            <dl class="layui-nav-child">-->
<!--                <!-- 二级菜单 -->-->
<!--                <dd>-->
<!--                    <a onclick="WeAdminShow('添加工时','https://www.youfa365.com/')"><i class="iconfont">&#xe6a2;</i>添加工时</a>-->
<!--                </dd>-->
<!--                <dd>-->
<!--                    <a onclick="WeAdminShow('审核工时','http://www.baidu.com')"><i class="iconfont">&#xe6a8;</i>审核工时</a>-->
<!--                </dd>-->
<!--                <dd>-->
<!--                    <a onclick="WeAdminShow('查看工时','https://www.youfa365.com/')"><i class="iconfont">&#xe6b8;</i>查看工时</a>-->
<!--                </dd>-->
<!--            </dl>-->
<!--        </li>-->
    </ul>
    <ul class="layui-nav right" lay-filter="">
        <li class="layui-nav-item">
            <a href="javascript:;"><?php echo $realname?></a>
            <dl class="layui-nav-child">
                <!-- 二级菜单 -->
                <dd>
                    <a onclick="WeAdminEdit('修改密码','/User/editPwd','editPwd',600,400)">修改密码</a>
                </dd>
                <dd>
                    <a onclick="WeAdminEdit('编辑个人信息','/User/editSelfInfo','editInfo',600,400)">编辑个人信息</a>
                </dd>
                <dd>
                    <a class="loginout" href="/Public/logout">退出</a>
                </dd>
            </dl>
        </li>
    </ul>

</div>
<!-- 顶部结束 -->