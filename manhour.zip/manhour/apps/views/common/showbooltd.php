<?php
function showBoolTd($data,$boolstr = "允许|不允许"){
    $html = "<td class='td-status'>";
    $statusBtnType = $data==1?'layui-btn':'layui-btn-danger';
    $html.="<span class='layui-btn ".$statusBtnType." layui-btn-xs'>";
    $boolstrs = explode("|",$boolstr);
    $trueStr = $boolstrs[0];
    $falseStr = $boolstrs[1];
    $html.=$data==1?$trueStr:$falseStr;
    $html.="</span></td>";
    return $html;
}
?>