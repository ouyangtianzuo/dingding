<div class="weadmin-body">
    <form class="layui-form" method="get" action="">
        <div class="layui-form-item">
            <label class="layui-form-label">项目名称</label>
            <div class="layui-input-inline">
                <select name="projectId" class="layui-select">
                    <?php foreach ($projectList as $project):?>
                        <option value="<?php echo $project["project_id"]?>"><?php echo $project["project_name"]?></option>
                    <?php endforeach ?>
                </select>
            </div>
        </div>
        <div class="layui-form-item">
            <div class="layui-input-block">
                <button class="layui-btn" lay-submit lay-filter="formDemo">立即提交</button>
            </div>
        </div>
    </form>

    <script>
        layui.use('form', function(){
            var form = layui.form;
        });
    </script>
</div>