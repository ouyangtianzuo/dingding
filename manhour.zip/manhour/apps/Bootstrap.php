<?php
/**
 * 应用自己的启动初始化文件。
 * -- 1、当与公共引导程序不一样则可以在这里自行配置。
 * @author fingerQin
 * @date 2016-09-07
 */

class Bootstrap extends \common\Bootstrap {
    
}